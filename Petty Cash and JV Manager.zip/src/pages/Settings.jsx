import { useState } from 'react';
import { Loader2, RotateCcw } from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from '@/components/ui/dialog';
import { useToast } from '@/components/ui/use-toast';
import useWorkspace from '@/hooks/useWorkspace';
import { useRole } from '@/lib/RoleContext';
import { resetDemoData } from '@/lib/data';
import {
  CASH_ACCOUNT,
  DEFAULT_BRANCHES,
  DEFAULT_CLUSTERS,
  EXPENSE_CATEGORIES,
  FUND_LIMIT,
  ROLES,
  peso
} from '@/lib/constants';

const RULES = [
  'A request cannot be submitted without at least one expense line and one supporting document.',
  'Voided requests are final — corrections require a new request linked to the voided one.',
  'Only posted requests appear in the Finance queue, and the JV total must equal the approved amount.',
  'The cluster manager must tick all three validation checks before approving.',
  'Attachments must be printed before the request can be posted.',
  'The journal voucher must balance before it can be posted.',
  'A deposit needs a deposit date and a bank reference.',
  'Every action is logged with user, role and timestamp — records are never deleted.'
];

export default function Settings() {
  const { toast } = useToast();
  const { identity } = useRole();
  const { reload, requests } = useWorkspace();
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [busy, setBusy] = useState(false);

  const reset = async () => {
    setBusy(true);
    try {
      await resetDemoData();
      await reload({ quiet: true });
      toast({ title: 'Demo data restored', description: 'The three sample requests are back.' });
      setConfirmOpen(false);
    } catch (error) {
      toast({ title: 'Reset failed', description: error.message, variant: 'destructive' });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-4 fade-up">
      <PageHeader
        eyebrow={`${identity.roleLabel} · ${identity.scopeLabel}`}
        title="Settings"
        description="Reference data, prototype rules and the demo dataset. This prototype runs without logins or email — use the role switcher at the top to test each view."
      />

      <section className="rounded-2xl border border-brand-line/80 bg-card p-4 shadow-soft">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="font-heading text-[15px] font-semibold">Demo data</h2>
            <p className="mt-0.5 max-w-xl text-[12px] leading-relaxed text-muted-foreground">
              {requests.length} request{requests.length === 1 ? '' : 's'} stored. Reset deletes the demo transactions and
              restores the three fictional records: a submitted request, a completed cycle and a voided request.
            </p>
          </div>
          <Button
            variant="outline"
            onClick={() => setConfirmOpen(true)}
            className="shrink-0 rounded-full border-[#E7C4BC] text-[#A13C2C] hover:bg-[#F8E0DC]"
          >
            <RotateCcw className="mr-1.5 h-4 w-4" /> Reset demo data
          </Button>
        </div>
      </section>

      <div className="grid gap-4 lg:grid-cols-2">
        <section className="rounded-2xl border border-brand-line/80 bg-card p-4 shadow-soft">
          <h2 className="font-heading text-[15px] font-semibold">Branches & clusters</h2>
          <p className="mt-0.5 text-[11.5px] text-muted-foreground">
            One petty cash fund per branch, {peso(FUND_LIMIT)} each
          </p>
          <div className="mt-3 space-y-2">
            {DEFAULT_CLUSTERS.map((cluster) => (
              <div key={cluster.id} className="rounded-xl border border-brand-line/70 p-2.5">
                <p className="text-[12px] font-semibold">
                  {cluster.name}
                  <span className="ml-1.5 font-normal text-brand-muted">· {cluster.manager_name}</span>
                </p>
                <div className="mt-1.5 flex flex-wrap gap-1.5">
                  {DEFAULT_BRANCHES.filter((branch) => branch.cluster_id === cluster.id).map((branch) => (
                    <span
                      key={branch.id}
                      className="rounded-full bg-brand-greenSoft/70 px-2 py-0.5 text-[10.5px] text-brand-green"
                    >
                      {branch.name} ({branch.code}) · {branch.staff_name}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </section>

        <section className="rounded-2xl border border-brand-line/80 bg-card p-4 shadow-soft">
          <h2 className="font-heading text-[15px] font-semibold">Chart of accounts</h2>
          <p className="mt-0.5 text-[11.5px] text-muted-foreground">
            Expense categories map to the accounts used on the journal voucher
          </p>
          <ul className="mt-3 space-y-1.5">
            {EXPENSE_CATEGORIES.map((category) => (
              <li key={category.code} className="flex items-baseline justify-between gap-2 text-[12px]">
                <span className="num text-brand-muted">{category.code}</span>
                <span className="flex-1 truncate">{category.account}</span>
                <span className="text-[10.5px] text-brand-muted">{category.name}</span>
              </li>
            ))}
            <li className="flex items-baseline justify-between gap-2 border-t border-brand-line/70 pt-1.5 text-[12px]">
              <span className="num text-brand-muted">{CASH_ACCOUNT.code}</span>
              <span className="flex-1 truncate font-medium">{CASH_ACCOUNT.name}</span>
              <span className="text-[10.5px] text-brand-muted">Credit</span>
            </li>
          </ul>
        </section>

        <section className="rounded-2xl border border-brand-line/80 bg-card p-4 shadow-soft">
          <h2 className="font-heading text-[15px] font-semibold">Roles & visibility</h2>
          <ul className="mt-2.5 space-y-2">
            {ROLES.map((role) => (
              <li key={role.id} className="rounded-xl bg-brand-paper/70 px-2.5 py-2">
                <p className="text-[12px] font-semibold">{role.label}</p>
                <p className="text-[11px] text-muted-foreground">{role.blurb}</p>
              </li>
            ))}
          </ul>
          <p className="mt-2 text-[11px] leading-relaxed text-brand-muted">
            Branch staff see their own branch only. Cluster managers see submitted requests in their cluster. Finance
            sees every record and only acts on posted requests.
          </p>
        </section>

        <section className="rounded-2xl border border-brand-line/80 bg-card p-4 shadow-soft">
          <h2 className="font-heading text-[15px] font-semibold">Business rules enforced</h2>
          <ul className="mt-2.5 space-y-1.5">
            {RULES.map((rule) => (
              <li key={rule} className="flex gap-2 text-[11.5px] leading-relaxed text-brand-inkSoft">
                <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-brand-yellow" />
                {rule}
              </li>
            ))}
          </ul>
        </section>
      </div>

      <Dialog open={confirmOpen} onOpenChange={setConfirmOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Reset demo data?</DialogTitle>
            <DialogDescription>
              All current requests, journal vouchers and deposits are removed and the three sample records are
              restored. This cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setConfirmOpen(false)} className="rounded-full">
              Cancel
            </Button>
            <Button
              onClick={reset}
              disabled={busy}
              className="rounded-full bg-[#A13C2C] text-white hover:bg-[#8A3123]"
            >
              {busy ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : <RotateCcw className="mr-1.5 h-4 w-4" />}
              Reset now
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}