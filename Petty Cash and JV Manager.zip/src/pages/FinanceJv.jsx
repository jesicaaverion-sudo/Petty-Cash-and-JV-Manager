import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, CheckCircle2, Loader2, ReceiptText, Send } from 'lucide-react';
import ExpenseLinesTable from '@/components/requests/ExpenseLinesTable';
import JvLinesEditor from '@/components/finance/JvLinesEditor';
import DepositForm from '@/components/finance/DepositForm';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';
import useWorkspace from '@/hooks/useWorkspace';
import { useRole } from '@/lib/RoleContext';
import {
  jvForRequest,
  postJv,
  recordDeposit,
  saveJv
} from '@/lib/data';
import { CASH_ACCOUNT, EXPENSE_CATEGORIES, formatDate, peso, todayISO } from '@/lib/constants';

function buildLines(request) {
  const groups = {};
  (request.lines || []).forEach((line) => {
    const category =
      EXPENSE_CATEGORIES.find((item) => item.name === line.category) ||
      EXPENSE_CATEGORIES[EXPENSE_CATEGORIES.length - 1];
    if (!groups[category.code]) {
      groups[category.code] = {
        account_code: category.code,
        account_name: category.account,
        particulars: [],
        debit: 0,
        credit: 0
      };
    }
    groups[category.code].debit += Number(line.amount) || 0;
    groups[category.code].particulars.push(line.payee);
  });

  const lines = Object.values(groups).map((group) => ({
    account_code: group.account_code,
    account_name: group.account_name,
    particulars:
      group.particulars.length > 1 ? `${group.particulars.length} items` : group.particulars[0] || '',
    debit: Number(group.debit.toFixed(2)),
    credit: 0
  }));

  lines.push({
    account_code: CASH_ACCOUNT.code,
    account_name: CASH_ACCOUNT.name,
    particulars: `Replenishment of ${request.branch_name} petty cash`,
    debit: 0,
    credit: Number(request.total_amount || 0)
  });

  return lines;
}

export default function FinanceJv() {
  const { requestId } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { identity } = useRole();
  const { requests, jvs, loading, reload } = useWorkspace();
  const [form, setForm] = useState(null);
  const [busy, setBusy] = useState(false);

  const request = requests.find((item) => item.id === requestId);
  const existingJv = request ? jvForRequest(jvs, request.id) : null;

  useEffect(() => {
    if (form || !request) return;
    setForm({
      jv_date: existingJv?.jv_date || todayISO(),
      particulars: existingJv?.particulars || `Petty cash replenishment — ${request.branch_name} branch`,
      lines: existingJv?.lines?.length ? existingJv.lines : buildLines(request)
    });
  }, [form, request, existingJv]);

  const run = async (fn, message) => {
    setBusy(true);
    try {
      const result = await fn();
      await reload({ quiet: true });
      if (message) toast({ title: message });
      return result;
    } catch (error) {
      toast({ title: 'Action blocked', description: error.message, variant: 'destructive' });
      return null;
    } finally {
      setBusy(false);
    }
  };

  if (loading || !form) {
    return <div className="h-40 animate-pulse rounded-2xl bg-brand-line/40" />;
  }

  if (!request) {
    return (
      <div className="rounded-2xl border border-brand-line bg-white p-8 text-center">
        <p className="font-heading text-[16px] font-semibold">Request not found</p>
        <Link to="/finance" className="mt-3 inline-block text-[12px] font-medium text-brand-green hover:underline">
          Back to Finance
        </Link>
      </div>
    );
  }

  if (!['Posted', 'JV Created', 'Deposited'].includes(request.status)) {
    return (
      <div className="rounded-2xl border border-brand-line bg-white p-8 text-center">
        <p className="font-heading text-[16px] font-semibold">Not yet available for vouchering</p>
        <p className="mt-1 text-[12.5px] text-muted-foreground">
          Only posted requests appear in the Finance queue. This request is {request.status.toLowerCase()}.
        </p>
        <Link to={`/requests/${request.id}`} className="mt-3 inline-block text-[12px] font-medium text-brand-green hover:underline">
          View the request
        </Link>
      </div>
    );
  }

  const voucherPosted = existingJv?.status === 'Posted';
  const readOnly = voucherPosted || request.status === 'Deposited';

  const handleSave = () =>
    run(
      () => saveJv({ request, identity, jvs, form, existingJv }),
      existingJv ? 'Journal voucher updated' : 'Journal voucher drafted'
    );

  const handlePost = async () => {
    const saved = await run(async () => {
      const jv = await saveJv({ request, identity, jvs, form, existingJv });
      return postJv(jv, request, identity);
    }, 'Journal voucher posted');
    return saved;
  };

  const handleDeposit = async (values) => {
    const done = await run(
      () => recordDeposit({ jv: existingJv, request, identity, form: values }),
      'Deposit recorded — replenishment complete'
    );
    if (done) navigate(`/requests/${request.id}`);
  };

  return (
    <div className="space-y-4 fade-up">
      <button
        type="button"
        onClick={() => navigate('/finance')}
        className="inline-flex items-center gap-1.5 text-[11.5px] font-medium text-brand-muted transition hover:text-brand-ink"
      >
        <ArrowLeft className="h-3.5 w-3.5" /> Finance queue
      </button>

      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-brand-muted">
            Journal voucher · {request.request_no}
          </p>
          <h1 className="mt-1 font-heading text-[24px] font-semibold">
            {existingJv ? existingJv.jv_no : 'New journal voucher'}
          </h1>
          <p className="mt-1 text-[12.5px] text-muted-foreground">
            {request.branch_name} Branch · approved {peso(request.total_amount)} · {formatDate(request.posted_at)}
          </p>
        </div>
        <div className="rounded-2xl border border-brand-line/80 bg-white px-4 py-2.5 text-right shadow-soft">
          <p className="text-[10px] font-semibold uppercase tracking-[0.14em] text-brand-muted">Voucher status</p>
          <p className="font-heading text-[14px] font-semibold">{existingJv?.status || 'Not started'}</p>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-[1.75fr_1fr]">
        <div className="space-y-4">
          <section className="rounded-2xl border border-brand-line/80 bg-card p-4 shadow-soft">
            <div className="flex items-center gap-2">
              <ReceiptText className="h-4 w-4 text-brand-green" />
              <h2 className="font-heading text-[15px] font-semibold">Voucher entry</h2>
            </div>
            <p className="mt-0.5 text-[11.5px] text-muted-foreground">
              Dr expense accounts / Cr cash in bank. The voucher must balance and equal the approved amount.
            </p>

            <div className="mt-3 grid gap-2.5 sm:grid-cols-2">
              <label className="block">
                <span className="text-[10.5px] font-semibold uppercase tracking-[0.12em] text-brand-muted">JV number</span>
                <Input
                  value={existingJv?.jv_no || 'Assigned when saved'}
                  readOnly
                  className="num mt-1 h-9 rounded-lg border-brand-line bg-brand-paper text-[12.5px]"
                />
              </label>
              <label className="block">
                <span className="text-[10.5px] font-semibold uppercase tracking-[0.12em] text-brand-muted">Voucher date</span>
                <Input
                  type="date"
                  value={form.jv_date}
                  disabled={readOnly}
                  onChange={(e) => setForm({ ...form, jv_date: e.target.value })}
                  className="mt-1 h-9 rounded-lg border-brand-line text-[12.5px]"
                />
              </label>
              <label className="block sm:col-span-2">
                <span className="text-[10.5px] font-semibold uppercase tracking-[0.12em] text-brand-muted">Particulars</span>
                <Input
                  value={form.particulars}
                  disabled={readOnly}
                  onChange={(e) => setForm({ ...form, particulars: e.target.value })}
                  className="mt-1 h-9 rounded-lg border-brand-line text-[12.5px]"
                />
              </label>
            </div>

            <div className="mt-3.5">
              <JvLinesEditor
                lines={form.lines}
                onChange={(lines) => setForm({ ...form, lines })}
                disabled={readOnly}
                requestTotal={request.total_amount}
              />
            </div>

            {!readOnly ? (
              <div className="mt-3 flex flex-col gap-2 sm:flex-row">
                <Button
                  onClick={handleSave}
                  disabled={busy}
                  variant="outline"
                  className="rounded-full border-brand-line"
                >
                  {busy ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : null}
                  Save draft
                </Button>
                <Button
                  onClick={handlePost}
                  disabled={busy}
                  className="rounded-full bg-brand-green text-white hover:bg-brand-green/90"
                >
                  <Send className="mr-1.5 h-4 w-4" /> Post journal voucher
                </Button>
              </div>
            ) : (
              <p className="mt-3 flex items-center gap-1.5 rounded-lg bg-brand-greenSoft/60 px-2.5 py-2 text-[11.5px] text-brand-green">
                <CheckCircle2 className="h-3.5 w-3.5" /> Voucher posted — no further edits allowed.
              </p>
            )}
          </section>

          <section className="rounded-2xl border border-brand-line/80 bg-card p-4 shadow-soft">
            <h2 className="font-heading text-[14px] font-semibold">Approved expenses</h2>
            <div className="mt-3">
              <ExpenseLinesTable lines={request.lines} total={request.total_amount} />
            </div>
          </section>
        </div>

        <aside className="space-y-4">
          {voucherPosted && request.status === 'JV Created' ? (
            <DepositForm request={request} onRecord={handleDeposit} busy={busy} />
          ) : (
            <div className="rounded-2xl border border-brand-line/80 bg-card p-4 shadow-soft">
              <h2 className="font-heading text-[14px] font-semibold">Deposit</h2>
              <p className="mt-1 text-[11.5px] leading-relaxed text-muted-foreground">
                {request.status === 'Deposited'
                  ? `Completed — ${peso(request.total_amount)} deposited, reference ${request.deposit_reference}.`
                  : 'Post the journal voucher first, then record the deposit date and bank reference to complete the replenishment.'}
              </p>
            </div>
          )}

          <div className="rounded-2xl border border-brand-line/80 bg-card p-4 shadow-soft">
            <h2 className="font-heading text-[14px] font-semibold">Request snapshot</h2>
            <dl className="mt-2.5 space-y-1.5 text-[11.5px]">
              <div className="flex justify-between gap-2">
                <dt className="text-brand-muted">Request</dt>
                <dd className="num font-medium">{request.request_no}</dd>
              </div>
              <div className="flex justify-between gap-2">
                <dt className="text-brand-muted">Branch</dt>
                <dd className="font-medium">{request.branch_name}</dd>
              </div>
              <div className="flex justify-between gap-2">
                <dt className="text-brand-muted">Approved by</dt>
                <dd className="font-medium">
                  {(request.activity || []).find((item) => item.action === 'Approved')?.actor || 'Cluster manager'}
                </dd>
              </div>
              <div className="flex justify-between gap-2">
                <dt className="text-brand-muted">Amount</dt>
                <dd className="num font-semibold">{peso(request.total_amount)}</dd>
              </div>
            </dl>
            <Link
              to={`/requests/${request.id}`}
              className="mt-3 inline-block text-[11.5px] font-medium text-brand-green hover:underline"
            >
              Open full record
            </Link>
          </div>
        </aside>
      </div>
    </div>
  );
}