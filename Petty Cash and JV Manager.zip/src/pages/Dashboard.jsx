import { Link } from 'react-router-dom';
import { AlertTriangle, ArrowRight, Clock, Plus, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import DashboardStat from '@/components/dashboard/DashboardStat';
import ActionQueue from '@/components/dashboard/ActionQueue';
import StatusBreakdown from '@/components/dashboard/StatusBreakdown';
import AmountTrend from '@/components/dashboard/AmountTrend';
import FundUsage from '@/components/dashboard/FundUsage';
import { useRole } from '@/lib/RoleContext';
import useWorkspace from '@/hooks/useWorkspace';
import { FUND_LIMIT, formatDate, peso } from '@/lib/constants';
import {
  actionQueueFor,
  agingRequests,
  kpisFor,
  monthlyTotals,
  scopeRequests,
  statusTotals
} from '@/lib/selectors';

export default function Dashboard() {
  const { identity, role, branches } = useRole();
  const { requests, loading, error } = useWorkspace();

  const scoped = scopeRequests(requests, identity);
  const kpis = kpisFor(scoped, role);
  const queue = actionQueueFor(scoped, role);
  const aging = agingRequests(scoped, role, 3);
  const trend = monthlyTotals(requests, 6);

  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';
  const firstName = identity.actorName.split(' ')[0];

  const fundBranches = (role === 'staff'
    ? branches.filter((b) => b.id === identity.branchId)
    : role === 'manager'
      ? branches.filter((b) => b.cluster_id === identity.clusterId)
      : branches
  ).map((branch) => ({
    name: branch.name,
    code: branch.code,
    outstanding: requests
      .filter((r) => r.branch_id === branch.id && !['Deposited', 'Voided'].includes(r.status))
      .reduce((total, r) => total + (Number(r.total_amount) || 0), 0)
  }));

  const kpiIcons = [Clock, Sparkles, ArrowRight, AlertTriangle];

  return (
    <div className="space-y-5 fade-up">
      <section className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
        <div>
          <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-brand-muted">
            BotiCARD Inc. · {identity.scopeLabel}
          </p>
          <h1 className="mt-1.5 font-heading text-[26px] font-semibold leading-tight sm:text-[32px]">
            {greeting}, {firstName}
          </h1>
          <p className="mt-1 max-w-xl text-[13px] leading-relaxed text-muted-foreground">
            {loading
              ? 'Loading your workspace…'
              : queue.length
                ? `${queue.length} request${queue.length > 1 ? 's' : ''} need${queue.length > 1 ? '' : 's'} your action as ${identity.roleLabel.toLowerCase()}.`
                : `Nothing is waiting on you as ${identity.roleLabel.toLowerCase()}.`}
          </p>
        </div>
        {role === 'staff' ? (
          <Button
            asChild
            size="lg"
            className="rounded-full bg-brand-yellow px-5 text-brand-ink shadow-[0_8px_20px_-10px_rgba(244,196,48,0.9)] hover:bg-brand-yellow/90"
          >
            <Link to="/requests/new">
              <Plus className="mr-1.5 h-4 w-4" strokeWidth={2.4} /> New reimbursement
            </Link>
          </Button>
        ) : (
          <div className="flex items-center gap-2 rounded-2xl border border-brand-line/80 bg-white/70 px-4 py-2.5 text-[12px] text-brand-inkSoft shadow-soft">
            <span className="h-2 w-2 rounded-full bg-brand-green" />
            {identity.roleLabel} workspace
          </div>
        )}
      </section>

      {error ? (
        <p className="rounded-xl bg-[#F8E0DC] px-3 py-2 text-[12px] text-[#A13C2C]">{error}</p>
      ) : null}

      <section className="grid grid-cols-2 gap-2.5 lg:grid-cols-4">
        {kpis.map((kpi, index) => (
          <DashboardStat
            key={kpi.label}
            label={kpi.label}
            value={kpi.value}
            sub={kpi.sub}
            tone={kpi.tone}
            icon={kpiIcons[index]}
          />
        ))}
      </section>

      <section className="grid gap-4 lg:grid-cols-3">
        <div className="rounded-2xl border border-brand-line/80 bg-card shadow-soft lg:col-span-2">
          <div className="flex items-center justify-between gap-3 border-b border-brand-line/70 px-4 py-3.5">
            <div>
              <h2 className="font-heading text-[15px] font-semibold">Needs your action</h2>
              <p className="text-[11.5px] text-muted-foreground">Oldest first — cleared as you process each request</p>
            </div>
            <Link
              to="/requests"
              className="flex shrink-0 items-center gap-1 text-[11.5px] font-medium text-brand-green hover:underline"
            >
              All requests <ArrowRight className="h-3.5 w-3.5" />
            </Link>
          </div>
          <div className="px-3 py-1.5 sm:px-4">
            {loading ? (
              <div className="space-y-3 py-3">
                {[0, 1, 2].map((row) => (
                  <div key={row} className="h-12 animate-pulse rounded-xl bg-brand-line/40" />
                ))}
              </div>
            ) : (
              <ActionQueue items={queue} emptyLabel="Queue is clear" />
            )}
          </div>
        </div>

        <div className="space-y-4">
          <div className="rounded-2xl border border-brand-line/80 bg-card p-4 shadow-soft">
            <h2 className="font-heading text-[14px] font-semibold">Amount per status</h2>
            <div className="mt-3">
              <StatusBreakdown rows={statusTotals(scoped)} />
            </div>
          </div>

          <div className="rounded-2xl border border-[#F3DFA6] bg-[#FFFAE8] p-4">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-[#8A6608]" strokeWidth={2.2} />
              <h2 className="font-heading text-[14px] font-semibold text-[#6F5206]">Aging alerts</h2>
            </div>
            {aging.length ? (
              <ul className="mt-2.5 space-y-2">
                {aging.slice(0, 3).map((item) => (
                  <li key={item.id}>
                    <Link
                      to={`/requests/${item.id}`}
                      className="flex items-center justify-between gap-2 rounded-lg bg-white/70 px-2.5 py-2 text-[12px] transition hover:bg-white"
                    >
                      <span className="min-w-0">
                        <span className="num block font-semibold">{item.request_no}</span>
                        <span className="block truncate text-[11px] text-muted-foreground">
                          {item.branch_name} · {formatDate(item.submitted_at)}
                        </span>
                      </span>
                      <span className="shrink-0 rounded-full bg-[#F8E0DC] px-2 py-0.5 text-[10px] font-semibold text-[#A13C2C]">
                        {item.aging}d
                      </span>
                    </Link>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="mt-2 text-[12px] text-[#7A6410]">Nothing has been waiting more than 3 days.</p>
            )}
          </div>
        </div>
      </section>

      <section className="grid gap-4 lg:grid-cols-3">
        <div className="rounded-2xl border border-brand-line/80 bg-card p-4 shadow-soft lg:col-span-2">
          <div className="flex flex-wrap items-baseline justify-between gap-2">
            <div>
              <h2 className="font-heading text-[15px] font-semibold">Replenishment trend</h2>
              <p className="text-[11.5px] text-muted-foreground">Submitted vs. deposited value, last 6 months</p>
            </div>
            <div className="flex items-center gap-3 text-[11px] text-brand-muted">
              <span className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-brand-yellow" /> Submitted
              </span>
              <span className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-brand-green" /> Deposited
              </span>
            </div>
          </div>
          <div className="mt-3">
            <AmountTrend data={trend} />
          </div>
        </div>

        <div className="rounded-2xl border border-brand-line/80 bg-card p-4 shadow-soft">
          <div className="flex items-baseline justify-between gap-2">
            <h2 className="font-heading text-[15px] font-semibold">Petty cash fund</h2>
            <span className="num text-[11px] text-brand-muted">{peso(FUND_LIMIT)} limit</span>
          </div>
          <p className="mt-0.5 text-[11.5px] text-muted-foreground">Outstanding balance against each branch fund</p>
          <div className="mt-3.5">
            <FundUsage rows={fundBranches} limit={FUND_LIMIT} />
          </div>
        </div>
      </section>
    </div>
  );
}