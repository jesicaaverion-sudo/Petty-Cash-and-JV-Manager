import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Download, Plus, Search } from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import RequestTable from '@/components/requests/RequestTable';
import EmptyState from '@/components/EmptyState';
import StatusPill from '@/components/StatusPill';
import useWorkspace from '@/hooks/useWorkspace';
import { useRole } from '@/lib/RoleContext';
import { downloadCsv } from '@/lib/exportCsv';
import { formatDate, peso } from '@/lib/constants';
import { scopeRequests } from '@/lib/selectors';
import { cn } from '@/lib/utils';

const STATUS_FILTERS = ['All', 'Draft', 'Submitted', 'Approved', 'Posted', 'JV Created', 'Deposited', 'Voided'];

export default function Requests() {
  const { identity, role, branches } = useRole();
  const { requests, loading, reload } = useWorkspace();
  const [status, setStatus] = useState('All');
  const [branch, setBranch] = useState('all');
  const [search, setSearch] = useState('');

  const scoped = scopeRequests(requests, identity);

  const filtered = useMemo(() => {
    const term = search.trim().toLowerCase();
    return scoped
      .filter((request) => (status === 'All' ? true : request.status === status))
      .filter((request) => (branch === 'all' ? true : request.branch_id === branch))
      .filter((request) => {
        if (!term) return true;
        const haystack = [
          request.request_no,
          request.branch_name,
          request.requester_name,
          ...(request.lines || []).map((line) => `${line.payee} ${line.category} ${line.reference}`)
        ]
          .join(' ')
          .toLowerCase();
        return haystack.includes(term);
      })
      .sort((a, b) => new Date(b.request_date || 0) - new Date(a.request_date || 0));
  }, [scoped, status, branch, search]);

  const exportRows = () => {
    const rows = [
      ['Request no.', 'Branch', 'Requester', 'Request date', 'Lines', 'Amount', 'Status', 'JV no.', 'Submitted'],
      ...filtered.map((request) => [
        request.request_no,
        request.branch_name,
        request.requester_name,
        request.request_date,
        (request.lines || []).length,
        Number(request.total_amount || 0).toFixed(2),
        request.status,
        request.jv_no || '',
        request.submitted_at ? formatDate(request.submitted_at) : ''
      ])
    ];
    downloadCsv(`petty-cash-requests-${new Date().toISOString().slice(0, 10)}.csv`, rows);
  };

  const total = filtered.reduce((sum, request) => sum + (Number(request.total_amount) || 0), 0);

  return (
    <div className="space-y-4 fade-up">
      <PageHeader
        eyebrow={`${identity.scopeLabel} · ${identity.roleLabel}`}
        title="Reimbursement requests"
        description="Search and filter every request in your scope. Branch staff see their own branch, cluster managers see submitted requests in their cluster, and Finance sees all records."
        actions={
          <>
            <button
              type="button"
              onClick={exportRows}
              disabled={!filtered.length}
              className="inline-flex items-center gap-1.5 rounded-full border border-brand-line bg-white px-3.5 py-2 text-[12px] font-medium transition hover:border-brand-yellow disabled:opacity-50"
            >
              <Download className="h-3.5 w-3.5" /> Export
            </button>
            {role === 'staff' ? (
              <Link
                to="/requests/new"
                className="inline-flex items-center gap-1.5 rounded-full bg-brand-yellow px-4 py-2 text-[12px] font-semibold text-brand-ink transition hover:bg-brand-yellow/90"
              >
                <Plus className="h-3.5 w-3.5" /> New request
              </Link>
            ) : null}
          </>
        }
      />

      <div className="rounded-2xl border border-brand-line/80 bg-card p-3 shadow-soft">
        <div className="flex flex-col gap-2.5 lg:flex-row lg:items-center">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-brand-muted" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search request no., branch, payee or reference"
              className="w-full rounded-full border border-brand-line bg-white py-2 pl-9 pr-3 text-[12.5px] outline-none transition focus:border-brand-yellow focus:ring-2 focus:ring-brand-yellow/30"
            />
          </div>
          {role !== 'staff' ? (
            <select
              value={branch}
              onChange={(e) => setBranch(e.target.value)}
              className="rounded-full border border-brand-line bg-white px-3 py-2 text-[12px] outline-none focus:border-brand-yellow"
              aria-label="Filter by branch"
            >
              <option value="all">All branches</option>
              {(role === 'manager'
                ? branches.filter((b) => b.cluster_id === identity.clusterId)
                : branches
              ).map((item) => (
                <option key={item.id} value={item.id}>
                  {item.name}
                </option>
              ))}
            </select>
          ) : null}
        </div>

        <div className="no-scrollbar mt-2.5 flex gap-1.5 overflow-x-auto pb-0.5">
          {STATUS_FILTERS.map((option) => {
            const active = option === status;
            const count =
              option === 'All'
                ? scoped.length
                : scoped.filter((request) => request.status === option).length;
            return (
              <button
                key={option}
                type="button"
                onClick={() => setStatus(option)}
                className={cn(
                  'shrink-0 rounded-full px-3 py-1.5 text-[11.5px] font-medium transition',
                  active
                    ? 'bg-brand-ink text-brand-paper'
                    : 'bg-brand-paper text-brand-inkSoft/80 hover:bg-brand-greenSoft/70'
                )}
              >
                {option}
                <span className={cn('ml-1.5 text-[10px]', active ? 'text-brand-yellow' : 'text-brand-muted')}>
                  {count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      <div className="flex items-center justify-between px-1 text-[11.5px] text-brand-muted">
        <span>
          {filtered.length} request{filtered.length === 1 ? '' : 's'} · {peso(total)} total
        </span>
        <button type="button" onClick={() => reload()} className="font-medium text-brand-green hover:underline">
          Refresh
        </button>
      </div>

      {loading ? (
        <div className="space-y-2">
          {[0, 1, 2, 3].map((row) => (
            <div key={row} className="h-14 animate-pulse rounded-2xl bg-brand-line/40" />
          ))}
        </div>
      ) : filtered.length ? (
        <RequestTable requests={filtered} showBranch />
      ) : (
        <EmptyState
          title="No requests match this view"
          description="Try clearing the search or status filter, or create a new reimbursement request."
          action={
            role === 'staff' ? (
              <Link
                to="/requests/new"
                className="inline-flex items-center gap-1.5 rounded-full bg-brand-yellow px-4 py-2 text-[12px] font-semibold text-brand-ink"
              >
                <Plus className="h-3.5 w-3.5" /> New request
              </Link>
            ) : null
          }
        />
      )}

      {!loading && filtered.length ? (
        <div className="flex flex-wrap gap-2 px-1">
          {STATUS_FILTERS.filter((option) => option !== 'All')
            .slice(0, 4)
            .map((option) => {
              const count = scoped.filter((request) => request.status === option).length;
              if (!count) return null;
              return (
                <span key={option} className="flex items-center gap-1.5 rounded-full bg-white px-2.5 py-1 shadow-soft">
                  <StatusPill status={option} size="sm" />
                </span>
              );
            })}
        </div>
      ) : null}
    </div>
  );
}