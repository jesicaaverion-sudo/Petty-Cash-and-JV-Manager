import { useEffect, useState } from 'react';
import { useNavigate, useParams, useSearchParams, Link } from 'react-router-dom';
import { ArrowLeft, Loader2, Save, Send } from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import ExpenseLinesEditor from '@/components/requests/ExpenseLinesEditor';
import DocumentUploader from '@/components/requests/DocumentUploader';
import CompletenessChecklist from '@/components/requests/CompletenessChecklist';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';
import useWorkspace from '@/hooks/useWorkspace';
import { useRole } from '@/lib/RoleContext';
import { createRequest, nextRequestNo, submitRequest, updateDraft } from '@/lib/data';
import { canSubmit } from '@/lib/rules';
import { FUND_LIMIT, peso, sumLines, todayISO } from '@/lib/constants';

const emptyLine = () => ({
  date: todayISO(),
  category: 'Fuel & Transportation',
  payee: '',
  reference: '',
  amount: '',
  remarks: ''
});

export default function NewRequest() {
  const { id } = useParams();
  const [searchParams] = useSearchParams();
  const fromId = searchParams.get('from');
  const navigate = useNavigate();
  const { toast } = useToast();
  const { identity } = useRole();
  const { requests, loading, reload } = useWorkspace();

  const editing = id ? requests.find((request) => request.id === id) : null;
  const source = fromId ? requests.find((request) => request.id === fromId) : null;

  const [form, setForm] = useState({
    request_date: todayISO(),
    notes: '',
    lines: [emptyLine()],
    documents: []
  });
  const [busy, setBusy] = useState(false);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    if (hydrated || loading) return;
    if (editing) {
      setForm({
        request_date: editing.request_date || todayISO(),
        notes: editing.notes || '',
        lines: editing.lines?.length ? editing.lines : [emptyLine()],
        documents: editing.documents || []
      });
    } else if (source) {
      setForm({
        request_date: todayISO(),
        notes: source.notes || '',
        lines: (source.lines || []).map((line) => ({ ...line, amount: Number(line.amount) || '' })),
        documents: []
      });
    }
    setHydrated(true);
  }, [hydrated, loading, editing, source]);

  const requestNo = editing ? editing.request_no : nextRequestNo(requests);
  const total = sumLines(form.lines);
  const limit = identity.branch?.fund_limit || FUND_LIMIT;
  const preview = { ...form, fund_limit: limit };
  const ready = canSubmit(preview);

  const save = async (submit) => {
    setBusy(true);
    try {
      let saved = editing;
      if (editing) {
        saved = await updateDraft(editing, form, identity);
      } else {
        saved = await createRequest({
          requests,
          identity,
          draft: form,
          previousRequestId: source?.id || '',
          previousRequestNo: source?.request_no || ''
        });
      }
      if (submit) {
        await submitRequest({ ...saved, ...form, total_amount: total }, identity);
      }
      await reload({ quiet: true });
      toast({
        title: submit ? 'Request submitted' : 'Draft saved',
        description: submit
          ? `${saved.request_no} is now with the cluster manager.`
          : `${saved.request_no} is saved and can still be edited.`
      });
      navigate(`/requests/${saved.id}`);
    } catch (error) {
      toast({ title: 'Not saved', description: error.message, variant: 'destructive' });
    } finally {
      setBusy(false);
    }
  };

  if (loading) {
    return (
      <div className="space-y-3">
        {[0, 1, 2].map((row) => (
          <div key={row} className="h-24 animate-pulse rounded-2xl bg-brand-line/40" />
        ))}
      </div>
    );
  }

  if (id && !editing) {
    return (
      <div className="rounded-2xl border border-brand-line bg-white p-6 text-center">
        <p className="font-heading text-[15px] font-semibold">This draft is not available</p>
        <p className="mt-1 text-[12.5px] text-muted-foreground">
          It may have already been submitted. Only drafts can be edited.
        </p>
        <Link to="/requests" className="mt-3 inline-block text-[12px] font-medium text-brand-green hover:underline">
          Back to requests
        </Link>
      </div>
    );
  }

  if (!identity.branch) {
    return (
      <div className="rounded-2xl border border-brand-line bg-white p-6 text-center">
        <p className="font-heading text-[15px] font-semibold">Requests are encoded by branch staff</p>
        <p className="mt-1 text-[12.5px] text-muted-foreground">
          Switch to Branch Staff in the header to create a petty cash request for a branch.
        </p>
        <Link to="/requests" className="mt-3 inline-block text-[12px] font-medium text-brand-green hover:underline">
          Back to requests
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-4 fade-up">
      <button
        type="button"
        onClick={() => navigate(-1)}
        className="inline-flex items-center gap-1.5 text-[11.5px] font-medium text-brand-muted transition hover:text-brand-ink"
      >
        <ArrowLeft className="h-3.5 w-3.5" /> Back
      </button>

      <PageHeader
        eyebrow={editing ? 'Editing draft' : 'New reimbursement request'}
        title={requestNo}
        description={
          source
            ? `Correcting ${source.request_no}. Fix the items the cluster manager flagged, attach the documents again, then submit.`
            : 'Encode the expenses paid from the branch petty cash fund and attach every supporting document.'
        }
      />

      {source ? (
        <div className="rounded-xl border border-[#F3DFA6] bg-[#FFFAE8] px-3 py-2.5 text-[12px] text-[#6F5206]">
          <span className="font-semibold">Correction notice on {source.request_no}: </span>
          {source.correction_notice || source.void_reason}
        </div>
      ) : null}

      <div className="grid gap-4 lg:grid-cols-[1.65fr_1fr]">
        <div className="space-y-4">
          <section className="rounded-2xl border border-brand-line/80 bg-card p-4 shadow-soft">
            <h2 className="font-heading text-[14px] font-semibold">Request details</h2>
            <div className="mt-3 grid gap-2.5 sm:grid-cols-2">
              <label className="block">
                <span className="text-[10.5px] font-semibold uppercase tracking-[0.12em] text-brand-muted">Request no.</span>
                <Input value={requestNo} readOnly className="num mt-1 h-9 rounded-lg border-brand-line bg-brand-paper text-[12.5px] font-medium" />
              </label>
              <label className="block">
                <span className="text-[10.5px] font-semibold uppercase tracking-[0.12em] text-brand-muted">Request date</span>
                <Input
                  type="date"
                  value={form.request_date}
                  onChange={(e) => setForm({ ...form, request_date: e.target.value })}
                  className="mt-1 h-9 rounded-lg border-brand-line text-[12.5px]"
                />
              </label>
              <label className="block">
                <span className="text-[10.5px] font-semibold uppercase tracking-[0.12em] text-brand-muted">Branch</span>
                <Input value={`${identity.branch.name} (${identity.branch.code})`} readOnly className="mt-1 h-9 rounded-lg border-brand-line bg-brand-paper text-[12.5px]" />
              </label>
              <label className="block">
                <span className="text-[10.5px] font-semibold uppercase tracking-[0.12em] text-brand-muted">Requester</span>
                <Input value={identity.actorName} readOnly className="mt-1 h-9 rounded-lg border-brand-line bg-brand-paper text-[12.5px]" />
              </label>
              <label className="block sm:col-span-2">
                <span className="text-[10.5px] font-semibold uppercase tracking-[0.12em] text-brand-muted">Notes</span>
                <Textarea
                  value={form.notes}
                  onChange={(e) => setForm({ ...form, notes: e.target.value })}
                  placeholder="Optional context for the cluster manager"
                  className="mt-1 min-h-[60px] rounded-lg border-brand-line text-[12.5px]"
                />
              </label>
            </div>
          </section>

          <section className="rounded-2xl border border-brand-line/80 bg-card p-4 shadow-soft">
            <div className="flex items-baseline justify-between gap-2">
              <h2 className="font-heading text-[14px] font-semibold">Expense lines</h2>
              <span className="text-[11px] text-brand-muted">Petty cash fund limit {peso(limit)}</span>
            </div>
            <div className="mt-3">
              <ExpenseLinesEditor
                lines={form.lines}
                onChange={(lines) => setForm({ ...form, lines })}
                limit={limit}
              />
            </div>
          </section>

          <section className="rounded-2xl border border-brand-line/80 bg-card p-4 shadow-soft">
            <h2 className="font-heading text-[14px] font-semibold">Supporting documents</h2>
            <p className="mt-0.5 text-[11.5px] text-muted-foreground">
              Petty cash vouchers, sales invoices and paid utility bills. Files are stored privately.
            </p>
            <div className="mt-3">
              <DocumentUploader
                documents={form.documents}
                onChange={(documents) => setForm({ ...form, documents })}
              />
            </div>
          </section>
        </div>

        <aside className="space-y-3 lg:sticky lg:top-24 lg:self-start">
          <div className="rounded-2xl border border-brand-line/80 bg-card p-4 shadow-soft">
            <h2 className="font-heading text-[14px] font-semibold">Before you submit</h2>
            <div className="mt-3">
              <CompletenessChecklist request={preview} />
            </div>
            <div className="mt-3 flex items-baseline justify-between border-t border-brand-line/70 pt-3">
              <span className="text-[11px] uppercase tracking-[0.12em] text-brand-muted">Request total</span>
              <span className="num font-heading text-[17px] font-semibold">{peso(total)}</span>
            </div>
            <div className="mt-3 space-y-2">
              <Button
                onClick={() => save(true)}
                disabled={busy || !ready}
                className="w-full rounded-full bg-brand-yellow text-brand-ink hover:bg-brand-yellow/90"
              >
                {busy ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : <Send className="mr-1.5 h-4 w-4" />}
                Submit for validation
              </Button>
              <Button
                variant="outline"
                onClick={() => save(false)}
                disabled={busy}
                className="w-full rounded-full border-brand-line"
              >
                <Save className="mr-1.5 h-4 w-4" /> Save draft
              </Button>
            </div>
            <p className="mt-2 text-center text-[10.5px] leading-snug text-brand-muted">
              Submitted requests can no longer be edited. The cluster manager must approve or void them.
            </p>
          </div>
        </aside>
      </div>
    </div>
  );
}