import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import {
  ArrowLeft,
  CircleSlash,
  Copy,
  Loader2,
  Printer,
  ReceiptText,
  Send,
  Stamp
} from 'lucide-react';
import StatusPill from '@/components/StatusPill';
import ExpenseLinesTable from '@/components/requests/ExpenseLinesTable';
import DocumentGrid from '@/components/requests/DocumentGrid';
import ApprovalTrail from '@/components/requests/ApprovalTrail';
import ReviewPanel from '@/components/requests/ReviewPanel';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import useWorkspace from '@/hooks/useWorkspace';
import { useRole } from '@/lib/RoleContext';
import {
  approveRequest,
  depositForRequest,
  jvForRequest,
  markAttachmentsPrinted,
  postRequest,
  submitRequest,
  voidRequest
} from '@/lib/data';
import { availableActions } from '@/lib/rules';
import { STATUS_ORDER, formatDate, formatDateTime, peso } from '@/lib/constants';
import { cn } from '@/lib/utils';

function StatusRail({ status }) {
  const currentIndex = STATUS_ORDER.indexOf(status);
  return (
    <ol className="flex items-center gap-1">
      {STATUS_ORDER.map((step, index) => {
        const done = currentIndex >= index && status !== 'Voided';
        return (
          <li key={step} className="flex-1" title={step}>
            <span
              className={cn(
                'block h-1.5 rounded-full transition-colors',
                status === 'Voided'
                  ? index === 0
                    ? 'bg-[#C4703F]'
                    : 'bg-brand-line'
                  : done
                    ? 'bg-brand-green'
                    : 'bg-brand-line'
              )}
            />
            <span className="mt-1 block truncate text-[9px] uppercase tracking-[0.08em] text-brand-muted">
              {step}
            </span>
          </li>
        );
      })}
    </ol>
  );
}

export default function RequestDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { identity, role } = useRole();
  const { requests, jvs, deposits, loading, reload } = useWorkspace();
  const [busy, setBusy] = useState(false);

  const request = requests.find((item) => item.id === id);
  const jv = request ? jvForRequest(jvs, request.id) : null;
  const deposit = request ? depositForRequest(deposits, request.id) : null;
  const actions = request ? availableActions(request, role) : {};

  useEffect(() => {
    if (loading || request) return undefined;
    const meta = document.createElement('meta');
    meta.name = 'prerender-status-code';
    meta.content = '404';
    document.head.appendChild(meta);
    return () => document.head.removeChild(meta);
  }, [loading, request]);

  const run = async (fn, message) => {
    setBusy(true);
    try {
      await fn();
      await reload({ quiet: true });
      if (message) toast({ title: message });
    } catch (error) {
      toast({ title: 'Action blocked', description: error.message, variant: 'destructive' });
    } finally {
      setBusy(false);
    }
  };

  if (loading) {
    return (
      <div className="space-y-3">
        {[0, 1, 2].map((row) => (
          <div key={row} className="h-28 animate-pulse rounded-2xl bg-brand-line/40" />
        ))}
      </div>
    );
  }

  if (!request) {
    return (
      <div className="rounded-2xl border border-brand-line bg-white p-8 text-center">
        <p className="font-heading text-[16px] font-semibold">Request not found</p>
        <p className="mt-1 text-[12.5px] text-muted-foreground">
          It may belong to another branch, cluster or status group.
        </p>
        <Link to="/requests" className="mt-3 inline-block text-[12px] font-medium text-brand-green hover:underline">
          Back to requests
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-4 fade-up">
      <div className="flex items-center justify-between no-print">
        <button
          type="button"
          onClick={() => navigate('/requests')}
          className="inline-flex items-center gap-1.5 text-[11.5px] font-medium text-brand-muted transition hover:text-brand-ink"
        >
          <ArrowLeft className="h-3.5 w-3.5" /> All requests
        </button>
        <button
          type="button"
          onClick={() => window.print()}
          className="inline-flex items-center gap-1.5 rounded-full border border-brand-line bg-white px-3 py-1.5 text-[11.5px] font-medium transition hover:border-brand-yellow"
        >
          <Printer className="h-3.5 w-3.5" /> Print view
        </button>
      </div>

      {request.status === 'Voided' ? (
        <div className="rounded-2xl border border-[#F0C9C1] bg-[#FDF1EF] p-4">
          <div className="flex items-start gap-2.5">
            <CircleSlash className="mt-0.5 h-4 w-4 shrink-0 text-[#A13C2C]" />
            <div>
              <p className="font-heading text-[13px] font-semibold text-[#8A3527]">
                Voided by the cluster manager — this cycle is closed
              </p>
              <p className="mt-1 text-[12px] leading-relaxed text-[#8A3527]">
                {request.void_reason || request.correction_notice}
              </p>
              {request.replaced_by ? (
                <p className="mt-1.5 text-[11.5px] text-[#8A3527]">
                  Replaced by{' '}
                  <Link to={`/requests/${request.replaced_by}`} className="font-semibold underline">
                    a corrected request
                  </Link>
                  .
                </p>
              ) : null}
              {actions.canReplace ? (
                <Button
                  asChild
                  size="sm"
                  className="mt-2.5 rounded-full bg-[#A13C2C] text-white hover:bg-[#8A3123] no-print"
                >
                  <Link to={`/requests/new?from=${request.id}`}>
                    <Copy className="mr-1.5 h-3.5 w-3.5" /> Create new request from this
                  </Link>
                </Button>
              ) : null}
            </div>
          </div>
        </div>
      ) : null}

      {request.previous_request_id ? (
        <p className="rounded-xl bg-brand-greenSoft/60 px-3 py-2 text-[11.5px] text-brand-green">
          This request corrects an earlier voided submission.{' '}
          <Link to={`/requests/${request.previous_request_id}`} className="font-semibold underline">
            View the voided request
          </Link>
        </p>
      ) : null}

      <section className="rounded-2xl border border-brand-line/80 bg-card p-4 shadow-soft sm:p-5">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <h1 className="num font-heading text-[22px] font-semibold">{request.request_no}</h1>
              <StatusPill status={request.status} />
            </div>
            <p className="mt-1 text-[12.5px] text-muted-foreground">
              {request.branch_name} Branch ({request.branch_code}) · {request.cluster_name}
            </p>
            <p className="text-[12.5px] text-muted-foreground">
              Requested by {request.requester_name} · {formatDate(request.request_date)}
            </p>
          </div>
          <div className="sm:text-right">
            <p className="text-[10px] font-semibold uppercase tracking-[0.16em] text-brand-muted">Total reimbursement</p>
            <p className="num font-heading text-[26px] font-semibold">{peso(request.total_amount)}</p>
            <p className="text-[11px] text-brand-muted">{request.lines?.length || 0} expense lines</p>
          </div>
        </div>

        <div className="mt-4">
          <StatusRail status={request.status} />
        </div>

        <div className="mt-4 flex flex-wrap items-center gap-2 no-print">
          {actions.canEdit ? (
            <Button asChild variant="outline" size="sm" className="rounded-full border-brand-line">
              <Link to={`/requests/${request.id}/edit`}>Edit draft</Link>
            </Button>
          ) : null}
          {actions.canSubmit ? (
            <Button
              size="sm"
              onClick={() => run(() => submitRequest(request, identity), 'Request submitted')}
              disabled={busy}
              className="rounded-full bg-brand-yellow text-brand-ink hover:bg-brand-yellow/90"
            >
              {busy ? <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" /> : <Send className="mr-1.5 h-3.5 w-3.5" />}
              Submit for validation
            </Button>
          ) : null}
          {role === 'manager' && request.status === 'Approved' ? (
            <>
              <Button
                size="sm"
                variant="outline"
                onClick={async () => {
                  await run(() => markAttachmentsPrinted(request, identity), 'Attachments marked as printed');
                  window.print();
                }}
                disabled={busy}
                className="rounded-full border-brand-line"
              >
                <Stamp className="mr-1.5 h-3.5 w-3.5" />
                {request.attachments_printed_at ? 'Print again' : 'Print attachments'}
              </Button>
              <Button
                size="sm"
                onClick={() => run(() => postRequest(request, identity), 'Request posted to Finance')}
                disabled={busy || !request.attachments_printed_at}
                className="rounded-full bg-brand-green text-white hover:bg-brand-green/90 disabled:opacity-50"
              >
                {busy ? <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" /> : <Send className="mr-1.5 h-3.5 w-3.5" />}
                Post to Finance
              </Button>
            </>
          ) : null}
          {actions.canPrepareJv ? (
            <Button asChild size="sm" className="rounded-full bg-brand-green text-white hover:bg-brand-green/90">
              <Link to={`/finance/jv/${request.id}`}>
                <ReceiptText className="mr-1.5 h-3.5 w-3.5" /> Prepare journal voucher
              </Link>
            </Button>
          ) : null}
          {actions.canEditJv ? (
            <Button asChild size="sm" className="rounded-full bg-brand-green text-white hover:bg-brand-green/90">
              <Link to={`/finance/jv/${request.id}`}>
                <ReceiptText className="mr-1.5 h-3.5 w-3.5" /> Continue voucher
              </Link>
            </Button>
          ) : null}
        </div>

        {role === 'manager' && request.status === 'Approved' && !request.attachments_printed_at ? (
          <p className="mt-2 text-[11.5px] text-[#8A6608] no-print">
            Print the supporting attachments before posting — the system records who printed and when.
          </p>
        ) : null}
      </section>

      <div className="grid gap-4 lg:grid-cols-[1.7fr_1fr]">
        <div className="space-y-4">
          <section className="rounded-2xl border border-brand-line/80 bg-card p-4 shadow-soft">
            <div className="flex items-baseline justify-between gap-2">
              <h2 className="font-heading text-[14px] font-semibold">Expense lines</h2>
              <span className="text-[11px] text-brand-muted">Fund limit {peso(request.fund_limit || 20000)}</span>
            </div>
            <div className="mt-3">
              <ExpenseLinesTable lines={request.lines} total={request.total_amount} limit={request.fund_limit} />
            </div>
            {request.notes ? (
              <p className="mt-3 rounded-xl bg-brand-paper px-3 py-2 text-[11.5px] leading-relaxed text-brand-inkSoft">
                <span className="font-semibold">Branch notes: </span>
                {request.notes}
              </p>
            ) : null}
          </section>

          <section className="rounded-2xl border border-brand-line/80 bg-card p-4 shadow-soft">
            <h2 className="font-heading text-[14px] font-semibold">Supporting documents</h2>
            <p className="mt-0.5 text-[11.5px] text-muted-foreground">
              {request.documents?.length || 0} attached · stored privately
            </p>
            <div className="mt-3">
              <DocumentGrid documents={request.documents} />
            </div>
            {request.attachments_printed_at ? (
              <p className="mt-2.5 rounded-lg bg-brand-greenSoft/60 px-2.5 py-1.5 text-[11px] text-brand-green">
                Marked as printed on {formatDateTime(request.attachments_printed_at)}.
              </p>
            ) : null}
          </section>

          <section className="rounded-2xl border border-brand-line/80 bg-card p-4 shadow-soft">
            <h2 className="font-heading text-[14px] font-semibold">Approval trail</h2>
            <p className="mt-0.5 text-[11.5px] text-muted-foreground">Every action is logged — records are never deleted</p>
            <div className="mt-3">
              <ApprovalTrail activity={request.activity} />
            </div>
          </section>
        </div>

        <aside className="space-y-4">
          {role === 'manager' && request.status === 'Submitted' ? (
            <ReviewPanel
              request={request}
              busy={busy}
              onApprove={(checks, notes) =>
                run(() => approveRequest(request, identity, checks, notes), 'Request approved')
              }
              onVoid={(corrections) =>
                run(() => voidRequest(request, identity, corrections), 'Request voided — staff notified')
              }
            />
          ) : null}

          <div className="rounded-2xl border border-brand-line/80 bg-card p-4 shadow-soft">
            <h2 className="font-heading text-[14px] font-semibold">Processing summary</h2>
            <dl className="mt-2.5 space-y-2 text-[11.5px]">
              {[
                ['Submitted', request.submitted_at],
                ['Approved', request.approved_at],
                ['Attachments printed', request.attachments_printed_at],
                ['Posted', request.posted_at],
                ['Journal voucher', request.jv_no],
                ['Deposited', request.deposited_at]
              ].map(([label, value]) => (
                <div key={label} className="flex items-baseline justify-between gap-2">
                  <dt className="text-brand-muted">{label}</dt>
                  <dd className="num text-right font-medium">
                    {value
                      ? label === 'Journal voucher'
                        ? value
                        : formatDateTime(value)
                      : '—'}
                  </dd>
                </div>
              ))}
            </dl>
            {deposit ? (
              <div className="mt-3 rounded-xl bg-brand-greenSoft/60 px-2.5 py-2 text-[11px] text-brand-green">
                Deposit {peso(deposit.amount)} on {formatDate(deposit.deposit_date)} · ref {deposit.bank_reference}
              </div>
            ) : null}
            {jv ? (
              <div className="mt-3 rounded-xl border border-brand-line/70 px-2.5 py-2 text-[11px]">
                <p className="flex items-center justify-between">
                  <span className="font-semibold">{jv.jv_no}</span>
                  <span className="text-brand-muted">{jv.status}</span>
                </p>
                <p className="mt-1 text-brand-muted">
                  Dr {peso(jv.total_debit)} / Cr {peso(jv.total_credit)} · {formatDate(jv.jv_date)}
                </p>
                {role === 'finance' && jv.status === 'Draft' ? (
                  <Link
                    to={`/finance/jv/${request.id}`}
                    className="mt-1.5 inline-block font-medium text-brand-green hover:underline no-print"
                  >
                    Continue voucher
                  </Link>
                ) : null}
              </div>
            ) : null}
          </div>

          {request.validation_notes ? (
            <div className="rounded-2xl border border-brand-line/80 bg-card p-4 shadow-soft">
              <h2 className="font-heading text-[13px] font-semibold">Manager's notes</h2>
              <p className="mt-1.5 text-[11.5px] leading-relaxed text-brand-inkSoft">{request.validation_notes}</p>
            </div>
          ) : null}
        </aside>
      </div>
    </div>
  );
}