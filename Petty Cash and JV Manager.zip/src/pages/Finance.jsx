import { Link } from 'react-router-dom';
import { ArrowRight, Banknote, CheckCircle2, ReceiptText } from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import EmptyState from '@/components/EmptyState';
import useWorkspace from '@/hooks/useWorkspace';
import { depositForRequest, jvForRequest } from '@/lib/data';
import { formatDate, peso } from '@/lib/constants';

function QueueRow({ request, jv, deposit, cta, hint }) {
  return (
    <div className="flex flex-col gap-2 border-b border-brand-line/70 py-3 last:border-0 sm:flex-row sm:items-center sm:justify-between">
      <div className="min-w-0">
        <p className="flex flex-wrap items-center gap-2">
          <span className="num font-heading text-[13px] font-semibold">{request.request_no}</span>
          <span className="text-[11px] text-brand-muted">{request.branch_name}</span>
        </p>
        <p className="mt-0.5 text-[11.5px] text-muted-foreground">
          {jv ? `${jv.jv_no} · ${jv.status}` : hint} · {formatDate(request.posted_at || request.request_date)}
        </p>
        {deposit ? (
          <p className="mt-0.5 text-[11px] text-brand-green">
            Deposited {formatDate(deposit.deposit_date)} · {deposit.bank_reference}
          </p>
        ) : null}
      </div>
      <div className="flex items-center justify-between gap-3 sm:justify-end">
        <span className="num font-heading text-[14px] font-semibold">{peso(request.total_amount)}</span>
        {cta}
      </div>
    </div>
  );
}

export default function Finance() {
  const { requests, jvs, deposits, loading } = useWorkspace();

  const posted = requests.filter((request) => request.status === 'Posted');
  const inProgress = requests.filter((request) => request.status === 'JV Created');
  const completed = requests
    .filter((request) => request.status === 'Deposited')
    .sort((a, b) => new Date(b.deposited_at || 0) - new Date(a.deposited_at || 0));

  const awaitingJvTotal = posted.reduce((sum, request) => sum + (Number(request.total_amount) || 0), 0);

  return (
    <div className="space-y-4 fade-up">
      <PageHeader
        eyebrow="Finance Department"
        title="Journal vouchers & deposits"
        description="Posted requests arrive here automatically. Prepare the journal voucher, post it once balanced, then record the deposit to complete the replenishment."
      />

      <section className="grid grid-cols-2 gap-2.5 lg:grid-cols-3">
        <div className="rounded-2xl border border-brand-line/80 bg-card p-4 shadow-soft">
          <p className="text-[10px] font-semibold uppercase tracking-[0.14em] text-brand-muted">Awaiting JV</p>
          <p className="num mt-2 font-heading text-[20px] font-semibold">{posted.length}</p>
          <p className="text-[11.5px] text-muted-foreground">{peso(awaitingJvTotal)} to record</p>
        </div>
        <div className="rounded-2xl border border-brand-line/80 bg-card p-4 shadow-soft">
          <p className="text-[10px] font-semibold uppercase tracking-[0.14em] text-brand-muted">In progress</p>
          <p className="num mt-2 font-heading text-[20px] font-semibold">{inProgress.length}</p>
          <p className="text-[11.5px] text-muted-foreground">Voucher drafted or posted</p>
        </div>
        <div className="col-span-2 rounded-2xl border border-brand-line/80 bg-card p-4 shadow-soft lg:col-span-1">
          <p className="text-[10px] font-semibold uppercase tracking-[0.14em] text-brand-muted">Completed</p>
          <p className="num mt-2 font-heading text-[20px] font-semibold">{completed.length}</p>
          <p className="text-[11.5px] text-muted-foreground">Deposits recorded</p>
        </div>
      </section>

      <section className="rounded-2xl border border-brand-line/80 bg-card p-4 shadow-soft">
        <div className="flex items-center gap-2">
          <ReceiptText className="h-4 w-4 text-brand-green" />
          <h2 className="font-heading text-[15px] font-semibold">Awaiting journal voucher</h2>
        </div>
        <div className="mt-2">
          {loading ? (
            <div className="h-16 animate-pulse rounded-xl bg-brand-line/40" />
          ) : posted.length ? (
            posted.map((request) => (
              <QueueRow
                key={request.id}
                request={request}
                jv={jvForRequest(jvs, request.id)}
                hint="Posted by cluster manager"
                cta={
                  <Link
                    to={`/finance/jv/${request.id}`}
                    className="inline-flex shrink-0 items-center gap-1 rounded-full bg-brand-yellow px-3 py-1.5 text-[11.5px] font-semibold text-brand-ink"
                  >
                    Prepare JV <ArrowRight className="h-3.5 w-3.5" />
                  </Link>
                }
              />
            ))
          ) : (
            <EmptyState
              title="No posted requests waiting"
              description="Requests appear here as soon as a cluster manager posts them."
            />
          )}
        </div>
      </section>

      <section className="rounded-2xl border border-brand-line/80 bg-card p-4 shadow-soft">
        <div className="flex items-center gap-2">
          <Banknote className="h-4 w-4 text-brand-green" />
          <h2 className="font-heading text-[15px] font-semibold">Voucher prepared — awaiting deposit</h2>
        </div>
        <div className="mt-2">
          {inProgress.length ? (
            inProgress.map((request) => {
              const jv = jvForRequest(jvs, request.id);
              return (
                <QueueRow
                  key={request.id}
                  request={request}
                  jv={jv}
                  deposit={depositForRequest(deposits, request.id)}
                  hint="Journal voucher drafted"
                  cta={
                    <Link
                      to={`/finance/jv/${request.id}`}
                      className="inline-flex shrink-0 items-center gap-1 rounded-full border border-brand-line px-3 py-1.5 text-[11.5px] font-medium"
                    >
                      {jv?.status === 'Posted' ? 'Record deposit' : 'Continue voucher'}
                    </Link>
                  }
                />
              );
            })
          ) : (
            <p className="py-4 text-[12px] text-muted-foreground">Nothing in progress.</p>
          )}
        </div>
      </section>

      <section className="rounded-2xl border border-brand-line/80 bg-card p-4 shadow-soft">
        <div className="flex items-center gap-2">
          <CheckCircle2 className="h-4 w-4 text-brand-green" />
          <h2 className="font-heading text-[15px] font-semibold">Completed replenishments</h2>
        </div>
        <div className="mt-2">
          {completed.length ? (
            completed
              .slice(0, 8)
              .map((request) => (
                <QueueRow
                  key={request.id}
                  request={request}
                  jv={jvForRequest(jvs, request.id)}
                  deposit={depositForRequest(deposits, request.id)}
                  hint="Deposited"
                  cta={
                    <Link
                      to={`/requests/${request.id}`}
                      className="shrink-0 text-[11.5px] font-medium text-brand-green hover:underline"
                    >
                      View record
                    </Link>
                  }
                />
              ))
          ) : (
            <p className="py-4 text-[12px] text-muted-foreground">No completed cycles yet.</p>
          )}
        </div>
      </section>
    </div>
  );
}