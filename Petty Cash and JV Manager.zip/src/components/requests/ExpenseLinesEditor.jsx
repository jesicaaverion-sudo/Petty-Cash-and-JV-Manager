import { Plus, Trash2 } from 'lucide-react';
import { EXPENSE_CATEGORIES, peso, sumLines } from '@/lib/constants';
import { cn } from '@/lib/utils';

const inputClass =
  'w-full rounded-lg border border-brand-line bg-white px-2.5 py-2 text-[12.5px] outline-none transition focus:border-brand-yellow focus:ring-2 focus:ring-brand-yellow/30 disabled:bg-brand-paper disabled:text-brand-muted';

export default function ExpenseLinesEditor({ lines = [], onChange, disabled = false, limit = 20000 }) {
  const total = sumLines(lines);
  const overLimit = total > limit;

  const patch = (index, patchValue) => {
    onChange(lines.map((line, i) => (i === index ? { ...line, ...patchValue } : line)));
  };

  const addLine = () => {
    onChange([
      ...lines,
      {
        date: new Date().toISOString().slice(0, 10),
        category: EXPENSE_CATEGORIES[0].name,
        payee: '',
        reference: '',
        amount: '',
        remarks: ''
      }
    ]);
  };

  const removeLine = (index) => onChange(lines.filter((_, i) => i !== index));

  return (
    <div className="space-y-3">
      <div className="hidden gap-2 px-1 text-[10px] font-semibold uppercase tracking-[0.12em] text-brand-muted lg:grid lg:grid-cols-[122px_1.1fr_1.1fr_1fr_110px_32px]">
        <span>Date</span>
        <span>Category</span>
        <span>Payee</span>
        <span>Reference no.</span>
        <span className="text-right">Amount</span>
        <span />
      </div>

      {lines.map((line, index) => (
        <div
          key={index}
          className="grid gap-2 rounded-xl border border-brand-line/70 bg-white p-2.5 lg:grid-cols-[122px_1.1fr_1.1fr_1fr_110px_32px] lg:items-center lg:border-0 lg:bg-transparent lg:p-0"
        >
          <input
            type="date"
            value={line.date || ''}
            disabled={disabled}
            onChange={(e) => patch(index, { date: e.target.value })}
            className={inputClass}
            aria-label={`Line ${index + 1} date`}
          />
          <select
            value={line.category || EXPENSE_CATEGORIES[0].name}
            disabled={disabled}
            onChange={(e) => patch(index, { category: e.target.value })}
            className={inputClass}
            aria-label={`Line ${index + 1} category`}
          >
            {EXPENSE_CATEGORIES.map((category) => (
              <option key={category.name} value={category.name}>
                {category.name}
              </option>
            ))}
          </select>
          <input
            value={line.payee || ''}
            disabled={disabled}
            placeholder="Payee"
            onChange={(e) => patch(index, { payee: e.target.value })}
            className={inputClass}
            aria-label={`Line ${index + 1} payee`}
          />
          <input
            value={line.reference || ''}
            disabled={disabled}
            placeholder="OR / invoice no."
            onChange={(e) => patch(index, { reference: e.target.value })}
            className={inputClass}
            aria-label={`Line ${index + 1} reference`}
          />
          <input
            type="number"
            min="0"
            step="0.01"
            value={line.amount ?? ''}
            disabled={disabled}
            placeholder="0.00"
            onChange={(e) => patch(index, { amount: e.target.value })}
            className={cn(inputClass, 'num text-right')}
            aria-label={`Line ${index + 1} amount`}
          />
          <button
            type="button"
            onClick={() => removeLine(index)}
            disabled={disabled}
            aria-label={`Remove line ${index + 1}`}
            className="justify-self-end rounded-lg p-1.5 text-brand-muted transition hover:bg-[#F8E0DC] hover:text-[#A13C2C] disabled:opacity-40 lg:justify-self-center"
          >
            <Trash2 className="h-4 w-4" />
          </button>
        </div>
      ))}

      {lines.length === 0 ? (
        <p className="rounded-xl border border-dashed border-brand-line px-3 py-6 text-center text-[12.5px] text-muted-foreground">
          No expense lines yet. Add the vouchers, invoices and bills paid from the fund.
        </p>
      ) : null}

      <div className="flex flex-col gap-2 border-t border-brand-line/70 pt-3 sm:flex-row sm:items-center sm:justify-between">
        <button
          type="button"
          onClick={addLine}
          disabled={disabled}
          className="inline-flex items-center justify-center gap-1.5 rounded-full border border-brand-line bg-white px-3.5 py-2 text-[12.5px] font-medium transition hover:border-brand-yellow hover:bg-brand-yellowSoft/40 disabled:opacity-50"
        >
          <Plus className="h-3.5 w-3.5" /> Add expense line
        </button>
        <div className="flex items-baseline justify-between gap-3 sm:justify-end">
          <span className="text-[11.5px] uppercase tracking-[0.12em] text-brand-muted">Running total</span>
          <span className={cn('num font-heading text-[18px] font-semibold', overLimit && 'text-[#A13C2C]')}>
            {peso(total)}
          </span>
        </div>
      </div>

      {overLimit ? (
        <p className="rounded-lg bg-[#F8E0DC] px-3 py-2 text-[11.5px] text-[#A13C2C]">
          The total exceeds the {peso(limit)} petty cash fund limit for this branch.
        </p>
      ) : null}
    </div>
  );
}