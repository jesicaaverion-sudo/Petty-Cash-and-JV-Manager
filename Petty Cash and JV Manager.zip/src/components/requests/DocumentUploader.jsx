import { useRef, useState } from 'react';
import { FileText, Loader2, Paperclip, Trash2, UploadCloud } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { DOCUMENT_TYPES } from '@/lib/constants';
import { cn } from '@/lib/utils';

const ACCEPTED = '.pdf,.jpg,.jpeg,.png,.webp';
const MAX_BYTES = 10 * 1024 * 1024;

export default function DocumentUploader({ documents = [], onChange, disabled = false }) {
  const inputRef = useRef(null);
  const [dragging, setDragging] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const upload = async (fileList) => {
    const files = Array.from(fileList || []);
    if (!files.length) return;
    setError('');
    setBusy(true);
    const added = [];
    try {
      for (const file of files) {
        if (file.size > MAX_BYTES) {
          setError(`${file.name} is larger than 10 MB.`);
          continue;
        }
        // Attachments are financial documents, so they are stored privately.
        const { file_uri } = await base44.integrations.Core.UploadPrivateFile({ file });
        added.push({
          name: file.name,
          type: DOCUMENT_TYPES[0],
          file_uri,
          size: file.size,
          uploaded_at: new Date().toISOString()
        });
      }
      if (added.length) onChange([...documents, ...added]);
    } catch (err) {
      setError(err.message || 'Upload failed. Please try again.');
    } finally {
      setBusy(false);
      if (inputRef.current) inputRef.current.value = '';
    }
  };

  const setType = (index, type) => {
    onChange(documents.map((doc, i) => (i === index ? { ...doc, type } : doc)));
  };

  const remove = (index) => onChange(documents.filter((_, i) => i !== index));

  return (
    <div className="space-y-3">
      <div
        onDragOver={(e) => {
          if (disabled) return;
          e.preventDefault();
          setDragging(true);
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={(e) => {
          if (disabled) return;
          e.preventDefault();
          setDragging(false);
          upload(e.dataTransfer.files);
        }}
        className={cn(
          'rounded-xl border-2 border-dashed px-4 py-6 text-center transition',
          dragging ? 'border-brand-yellow bg-brand-yellowSoft/40' : 'border-brand-line bg-brand-paper/50',
          disabled && 'opacity-60'
        )}
      >
        <input
          ref={inputRef}
          type="file"
          multiple
          accept={ACCEPTED}
          className="hidden"
          onChange={(e) => upload(e.target.files)}
        />
        <span className="mx-auto grid h-10 w-10 place-items-center rounded-full bg-brand-greenSoft text-brand-green">
          {busy ? <Loader2 className="h-5 w-5 animate-spin" /> : <UploadCloud className="h-5 w-5" />}
        </span>
        <p className="mt-2 text-[12.5px] font-medium">
          {busy ? 'Uploading…' : 'Drag and drop vouchers, invoices or bills'}
        </p>
        <p className="mt-0.5 text-[11px] text-muted-foreground">PDF, JPG or PNG · up to 10 MB each</p>
        <button
          type="button"
          disabled={disabled || busy}
          onClick={() => inputRef.current?.click()}
          className="mt-2.5 inline-flex items-center gap-1.5 rounded-full border border-brand-line bg-white px-3 py-1.5 text-[11.5px] font-medium transition hover:border-brand-yellow disabled:opacity-50"
        >
          <Paperclip className="h-3.5 w-3.5" /> Choose files
        </button>
      </div>

      {error ? (
        <p className="rounded-lg bg-[#F8E0DC] px-3 py-2 text-[11.5px] text-[#A13C2C]">{error}</p>
      ) : null}

      {documents.length ? (
        <ul className="space-y-2">
          {documents.map((doc, index) => (
            <li
              key={`${doc.name}-${index}`}
              className="flex flex-wrap items-center gap-2 rounded-xl border border-brand-line/70 bg-white px-2.5 py-2"
            >
              <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-brand-yellowSoft/60 text-brand-ink">
                <FileText className="h-4 w-4" />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block truncate text-[12px] font-medium">{doc.name}</span>
                <span className="block text-[10.5px] text-brand-muted">
                  {(doc.size / 1024).toFixed(0)} KB · attached
                </span>
              </span>
              <select
                value={doc.type}
                disabled={disabled}
                onChange={(e) => setType(index, e.target.value)}
                className="rounded-lg border border-brand-line bg-white px-2 py-1 text-[11px] outline-none disabled:bg-brand-paper"
                aria-label={`Document type for ${doc.name}`}
              >
                {DOCUMENT_TYPES.map((type) => (
                  <option key={type} value={type}>
                    {type}
                  </option>
                ))}
              </select>
              <button
                type="button"
                onClick={() => remove(index)}
                disabled={disabled}
                aria-label={`Remove ${doc.name}`}
                className="rounded-lg p-1.5 text-brand-muted transition hover:bg-[#F8E0DC] hover:text-[#A13C2C] disabled:opacity-40"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </li>
          ))}
        </ul>
      ) : null}
    </div>
  );
}