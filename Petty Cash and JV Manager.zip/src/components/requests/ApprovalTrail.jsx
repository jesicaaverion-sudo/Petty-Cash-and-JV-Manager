import { formatDateTime } from '@/lib/constants';
import { cn } from '@/lib/utils';

const ACCENT = {
  'Branch Staff': 'bg-brand-yellow',
  'Cluster Manager': 'bg-brand-green',
  Finance: 'bg-[#5B4A8C]'
};

export default function ApprovalTrail({ activity = [] }) {
  if (!activity.length) {
    return <p className="text-[12px] text-muted-foreground">No activity recorded yet.</p>;
  }

  return (
    <ol className="relative space-y-4 border-l border-brand-line pl-4">
      {activity.map((entry, index) => (
        <li key={`${entry.action}-${index}`} className="relative">
          <span
            className={cn(
              'absolute -left-[21px] top-1 h-2.5 w-2.5 rounded-full ring-4 ring-white',
              ACCENT[entry.role] || 'bg-brand-muted'
            )}
          />
          <p className="text-[12.5px] font-medium leading-snug">{entry.action}</p>
          <p className="text-[11px] text-brand-muted">
            {entry.actor} · {entry.role} · {formatDateTime(entry.at)}
          </p>
          {entry.note ? (
            <p className="mt-1 rounded-lg bg-brand-paper px-2.5 py-1.5 text-[11.5px] leading-relaxed text-brand-inkSoft">
              {entry.note}
            </p>
          ) : null}
        </li>
      ))}
    </ol>
  );
}