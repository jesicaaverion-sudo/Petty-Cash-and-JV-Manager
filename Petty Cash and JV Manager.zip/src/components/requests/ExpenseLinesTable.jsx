import { peso } from '@/lib/constants';

export default function ExpenseLinesTable({ lines = [], total = 0, limit }) {
  return (
    <div className="overflow-hidden rounded-xl border border-brand-line/70">
      <div className="overflow-x-auto">
        <table className="w-full border-collapse text-left text-[12px]">
          <thead>
            <tr className="bg-brand-paper/70 text-[9.5px] uppercase tracking-[0.12em] text-brand-muted">
              <th className="px-3 py-2 font-semibold">Date</th>
              <th className="px-3 py-2 font-semibold">Category</th>
              <th className="px-3 py-2 font-semibold">Payee</th>
              <th className="px-3 py-2 font-semibold">Reference</th>
              <th className="px-3 py-2 text-right font-semibold">Amount</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-brand-line/70 bg-white">
            {lines.map((line, index) => (
              <tr key={index}>
                <td className="whitespace-nowrap px-3 py-2 text-brand-inkSoft">{line.date}</td>
                <td className="px-3 py-2">{line.category}</td>
                <td className="px-3 py-2">
                  {line.payee}
                  {line.remarks ? (
                    <span className="block text-[10.5px] text-brand-muted">{line.remarks}</span>
                  ) : null}
                </td>
                <td className="num px-3 py-2 text-brand-muted">
                  {line.reference || <span className="text-[#A13C2C]">missing</span>}
                </td>
                <td className="num px-3 py-2 text-right font-medium">{peso(line.amount)}</td>
              </tr>
            ))}
            {lines.length === 0 ? (
              <tr>
                <td colSpan={5} className="px-3 py-6 text-center text-brand-muted">
                  No expense lines recorded.
                </td>
              </tr>
            ) : null}
          </tbody>
          <tfoot>
            <tr className="border-t border-brand-line bg-brand-paper/60">
              <td colSpan={4} className="px-3 py-2.5 text-right text-[11px] uppercase tracking-[0.12em] text-brand-muted">
                Total {limit ? `/ ${peso(limit)} fund limit` : ''}
              </td>
              <td className="num px-3 py-2.5 text-right font-heading text-[13px] font-semibold">{peso(total)}</td>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  );
}