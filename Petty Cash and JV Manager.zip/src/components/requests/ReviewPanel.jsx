import { useState } from 'react';
import { CircleCheck, CircleX, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from '@/components/ui/dialog';
import { cn } from '@/lib/utils';

const CHECKS = [
  { key: 'details', label: 'Details are correct', hint: 'Branch, dates, categories and payees agree with the vouchers.' },
  { key: 'documents', label: 'Documents are complete', hint: 'Vouchers, sales invoices and paid utility bills are all attached.' },
  { key: 'amounts', label: 'Amounts match the receipts', hint: 'Every encoded amount equals the attached receipt.' }
];

export default function ReviewPanel({ request, busy, onApprove, onVoid }) {
  const [checks, setChecks] = useState(request?.checks || { details: false, documents: false, amounts: false });
  const [notes, setNotes] = useState(request?.validation_notes || '');
  const [voidOpen, setVoidOpen] = useState(false);
  const [corrections, setCorrections] = useState('');
  const [error, setError] = useState('');

  const allChecked = checks.details && checks.documents && checks.amounts;

  const submitVoid = async () => {
    if (!corrections.trim()) {
      setError('Write the corrections the branch staff must make.');
      return;
    }
    setError('');
    await onVoid(corrections);
    setVoidOpen(false);
  };

  return (
    <div className="rounded-2xl border border-brand-line/80 bg-card p-4 shadow-soft">
      <h2 className="font-heading text-[14px] font-semibold">Validation checklist</h2>
      <p className="mt-0.5 text-[11.5px] text-muted-foreground">
        All three checks must be ticked before approving.
      </p>

      <div className="mt-3 space-y-2">
        {CHECKS.map((check) => {
          const active = Boolean(checks[check.key]);
          return (
            <label
              key={check.key}
              className={cn(
                'flex cursor-pointer items-start gap-2.5 rounded-xl border p-2.5 transition',
                active ? 'border-brand-green/40 bg-brand-greenSoft/50' : 'border-brand-line bg-white hover:border-brand-yellow'
              )}
            >
              <input
                type="checkbox"
                checked={active}
                onChange={(e) => setChecks({ ...checks, [check.key]: e.target.checked })}
                className="mt-0.5 h-4 w-4 shrink-0 accent-[#2E6B4F]"
                disabled={busy}
              />
              <span>
                <span className="block text-[12px] font-medium">{check.label}</span>
                <span className="block text-[11px] leading-snug text-muted-foreground">{check.hint}</span>
              </span>
            </label>
          );
        })}
      </div>

      <label className="mt-3 block">
        <span className="text-[10.5px] font-semibold uppercase tracking-[0.12em] text-brand-muted">
          Validation notes
        </span>
        <Textarea
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="Optional remarks for the audit trail"
          className="mt-1 min-h-[64px] rounded-xl border-brand-line text-[12.5px]"
          disabled={busy}
        />
      </label>

      <div className="mt-3 flex flex-col gap-2 sm:flex-row">
        <Button
          onClick={() => onApprove(checks, notes)}
          disabled={!allChecked || busy}
          className="flex-1 rounded-full bg-brand-green text-white hover:bg-brand-green/90"
        >
          {busy ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : <CircleCheck className="mr-1.5 h-4 w-4" />}
          Approve reimbursement
        </Button>
        <Button
          variant="outline"
          onClick={() => setVoidOpen(true)}
          disabled={busy}
          className="rounded-full border-[#E7C4BC] text-[#A13C2C] hover:bg-[#F8E0DC]"
        >
          <CircleX className="mr-1.5 h-4 w-4" /> Void
        </Button>
      </div>

      <Dialog open={voidOpen} onOpenChange={setVoidOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Void this request</DialogTitle>
            <DialogDescription>
              Voiding ends this cycle. The branch staff is notified and must submit a new request with
              the corrections.
            </DialogDescription>
          </DialogHeader>
          <label className="block">
            <span className="text-[11px] font-semibold uppercase tracking-[0.12em] text-brand-muted">
              Corrections required
            </span>
            <Textarea
              value={corrections}
              onChange={(e) => setCorrections(e.target.value)}
              placeholder="e.g. The Caltex receipt has no OR number and the petty cash voucher is missing."
              className="mt-1 min-h-[96px] rounded-xl border-brand-line text-[12.5px]"
            />
          </label>
          {error ? <p className="text-[11.5px] text-[#A13C2C]">{error}</p> : null}
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setVoidOpen(false)} className="rounded-full">
              Cancel
            </Button>
            <Button onClick={submitVoid} disabled={busy} className="rounded-full bg-[#A13C2C] text-white hover:bg-[#8A3123]">
              {busy ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : <CircleX className="mr-1.5 h-4 w-4" />}
              Void request
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}