import { Link } from 'react-router-dom';
import StatusPill from '@/components/StatusPill';
import { daysSince, formatDate, peso } from '@/lib/constants';

export default function RequestTable({ requests = [], showBranch = true }) {
  return (
    <>
      <div className="hidden overflow-hidden rounded-2xl border border-brand-line/80 bg-card shadow-soft md:block">
        <table className="w-full border-collapse text-left text-[12.5px]">
          <thead>
            <tr className="bg-brand-paper/70 text-[9.5px] uppercase tracking-[0.14em] text-brand-muted">
              <th className="px-4 py-2.5 font-semibold">Request</th>
              {showBranch ? <th className="px-4 py-2.5 font-semibold">Branch</th> : null}
              <th className="px-4 py-2.5 font-semibold">Requester</th>
              <th className="px-4 py-2.5 font-semibold">Date</th>
              <th className="px-4 py-2.5 text-right font-semibold">Amount</th>
              <th className="px-4 py-2.5 font-semibold">Status</th>
              <th className="px-4 py-2.5 text-right font-semibold">Age</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-brand-line/70">
            {requests.map((request) => {
              const age = daysSince(request.submitted_at || request.request_date);
              return (
                <tr key={request.id} className="transition-colors hover:bg-brand-greenSoft/30">
                  <td className="px-4 py-3">
                    <Link to={`/requests/${request.id}`} className="num font-heading text-[12.5px] font-semibold hover:underline">
                      {request.request_no}
                    </Link>
                  </td>
                  {showBranch ? (
                    <td className="px-4 py-3">
                      <span className="block">{request.branch_name}</span>
                      <span className="text-[10.5px] text-brand-muted">{request.branch_code}</span>
                    </td>
                  ) : null}
                  <td className="px-4 py-3 text-brand-inkSoft">{request.requester_name}</td>
                  <td className="px-4 py-3 text-brand-inkSoft">{formatDate(request.request_date)}</td>
                  <td className="num px-4 py-3 text-right font-semibold">{peso(request.total_amount)}</td>
                  <td className="px-4 py-3">
                    <StatusPill status={request.status} size="sm" />
                  </td>
                  <td className="px-4 py-3 text-right text-[11.5px] text-brand-muted">
                    {['Draft', 'Voided', 'Deposited'].includes(request.status) ? '—' : `${age}d`}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <div className="space-y-2 md:hidden">
        {requests.map((request) => (
          <Link
            key={request.id}
            to={`/requests/${request.id}`}
            className="block rounded-2xl border border-brand-line/80 bg-card p-3 shadow-soft"
          >
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <p className="num font-heading text-[12.5px] font-semibold">{request.request_no}</p>
                <p className="truncate text-[11.5px] text-muted-foreground">
                  {showBranch ? `${request.branch_name} · ` : ''}
                  {request.requester_name}
                </p>
              </div>
              <StatusPill status={request.status} size="sm" />
            </div>
            <div className="mt-2 flex items-end justify-between">
              <span className="text-[11px] text-brand-muted">{formatDate(request.request_date)}</span>
              <span className="num font-heading text-[14px] font-semibold">{peso(request.total_amount)}</span>
            </div>
          </Link>
        ))}
      </div>
    </>
  );
}