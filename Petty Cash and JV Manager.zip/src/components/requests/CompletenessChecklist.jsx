import { Check, X } from 'lucide-react';
import { submitIssues } from '@/lib/rules';
import { cn } from '@/lib/utils';

export default function CompletenessChecklist({ request, compact = false }) {
  const items = submitIssues(request);

  return (
    <ul className={cn('space-y-2', compact && 'space-y-1.5')}>
      {items.map((item) => (
        <li key={item.key} className="flex items-start gap-2">
          <span
            className={cn(
              'mt-0.5 grid h-4 w-4 shrink-0 place-items-center rounded-full',
              item.ok ? 'bg-brand-green text-white' : 'bg-[#F8E0DC] text-[#A13C2C]'
            )}
          >
            {item.ok ? <Check className="h-2.5 w-2.5" strokeWidth={3} /> : <X className="h-2.5 w-2.5" strokeWidth={3} />}
          </span>
          <span className="min-w-0">
            <span className={cn('block text-[12px] font-medium', !item.ok && 'text-[#8A3527]')}>
              {item.label}
            </span>
            <span className="block text-[11px] leading-snug text-muted-foreground">{item.hint}</span>
          </span>
        </li>
      ))}
    </ul>
  );
}