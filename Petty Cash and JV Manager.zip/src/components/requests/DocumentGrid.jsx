import { useState } from 'react';
import { Download, Eye, FileText, ImageIcon } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle
} from '@/components/ui/dialog';

const isImage = (doc) => /\.(png|jpe?g|webp|gif)$/i.test(doc?.name || '');

async function resolveUrl(doc) {
  if (!doc?.file_uri) throw new Error('This sample record has no file attached.');
  if (/^https?:/i.test(doc.file_uri)) return doc.file_uri;
  const { signed_url } = await base44.integrations.Core.CreateFileSignedUrl({
    file_uri: doc.file_uri,
    expires_in: 600
  });
  return signed_url;
}

export default function DocumentGrid({ documents = [], compact = false }) {
  const [active, setActive] = useState(null);
  const [url, setUrl] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const open = async (doc) => {
    setActive(doc);
    setUrl('');
    setError('');
    setLoading(true);
    try {
      setUrl(await resolveUrl(doc));
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (!documents.length) {
    return (
      <p className="rounded-xl border border-dashed border-brand-line px-3 py-6 text-center text-[12px] text-muted-foreground">
        No supporting documents attached.
      </p>
    );
  }

  return (
    <>
      <div className={compact ? 'flex flex-wrap gap-2' : 'grid gap-2 sm:grid-cols-2'}>
        {documents.map((doc, index) => (
          <button
            key={`${doc.name}-${index}`}
            type="button"
            onClick={() => open(doc)}
            className="group flex items-center gap-2.5 rounded-xl border border-brand-line/70 bg-white p-2.5 text-left transition hover:border-brand-yellow hover:shadow-soft"
          >
            <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-brand-greenSoft text-brand-green">
              {isImage(doc) ? <ImageIcon className="h-4 w-4" /> : <FileText className="h-4 w-4" />}
            </span>
            <span className="min-w-0 flex-1">
              <span className="block truncate text-[12px] font-medium">{doc.name}</span>
              <span className="block text-[10.5px] text-brand-muted">{doc.type}</span>
            </span>
            <Eye className="h-4 w-4 shrink-0 text-brand-muted group-hover:text-brand-ink" />
          </button>
        ))}
      </div>

      <Dialog open={Boolean(active)} onOpenChange={(openState) => !openState && setActive(null)}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle className="truncate text-[15px]">{active?.name}</DialogTitle>
          </DialogHeader>
          <div className="max-h-[70vh] overflow-auto rounded-xl bg-brand-paper p-2">
            {loading ? (
              <p className="py-16 text-center text-[12.5px] text-muted-foreground">Opening document…</p>
            ) : error ? (
              <p className="py-16 text-center text-[12.5px] text-[#A13C2C]">{error}</p>
            ) : isImage(active) ? (
              <img src={url} alt={active?.name} className="mx-auto max-h-[66vh] rounded-lg object-contain" />
            ) : (
              <iframe src={url} title={active?.name} className="h-[66vh] w-full rounded-lg bg-white" />
            )}
          </div>
          {url ? (
            <a
              href={url}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1.5 self-start rounded-full border border-brand-line px-3 py-1.5 text-[11.5px] font-medium hover:border-brand-yellow"
            >
              <Download className="h-3.5 w-3.5" /> Open in new tab
            </a>
          ) : null}
        </DialogContent>
      </Dialog>
    </>
  );
}