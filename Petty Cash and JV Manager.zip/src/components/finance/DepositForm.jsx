import { useState } from 'react';
import { Banknote, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { peso, todayISO } from '@/lib/constants';

export default function DepositForm({ request, onRecord, busy }) {
  const [form, setForm] = useState({
    deposit_date: todayISO(),
    bank_reference: '',
    amount: request?.total_amount ?? 0
  });
  const [error, setError] = useState('');

  const submit = async () => {
    if (!form.deposit_date) return setError('Enter the deposit date.');
    if (!form.bank_reference.trim()) return setError('Enter the bank reference of the deposit.');
    if (Number(form.amount) !== Number(request.total_amount)) {
      return setError(`The deposit must equal ${peso(request.total_amount)}.`);
    }
    setError('');
    await onRecord(form);
  };

  return (
    <div className="rounded-2xl border border-brand-line/80 bg-card p-4 shadow-soft">
      <div className="flex items-center gap-2">
        <span className="grid h-8 w-8 place-items-center rounded-full bg-brand-greenSoft text-brand-green">
          <Banknote className="h-4 w-4" />
        </span>
        <div>
          <h2 className="font-heading text-[14px] font-semibold">Record the deposit</h2>
          <p className="text-[11px] text-muted-foreground">Funds returned to the branch petty cash account</p>
        </div>
      </div>

      <div className="mt-3 grid gap-2.5 sm:grid-cols-2">
        <label className="block">
          <span className="text-[10.5px] font-semibold uppercase tracking-[0.12em] text-brand-muted">Deposit date</span>
          <Input
            type="date"
            value={form.deposit_date}
            onChange={(e) => setForm({ ...form, deposit_date: e.target.value })}
            className="mt-1 h-9 rounded-lg border-brand-line text-[12.5px]"
          />
        </label>
        <label className="block">
          <span className="text-[10.5px] font-semibold uppercase tracking-[0.12em] text-brand-muted">Bank reference</span>
          <Input
            value={form.bank_reference}
            onChange={(e) => setForm({ ...form, bank_reference: e.target.value })}
            placeholder="e.g. BDO-0912-4471"
            className="mt-1 h-9 rounded-lg border-brand-line text-[12.5px]"
          />
        </label>
        <label className="block sm:col-span-2">
          <span className="text-[10.5px] font-semibold uppercase tracking-[0.12em] text-brand-muted">Amount</span>
          <Input
            type="number"
            step="0.01"
            value={form.amount}
            onChange={(e) => setForm({ ...form, amount: e.target.value })}
            className="num mt-1 h-9 rounded-lg border-brand-line text-[12.5px]"
          />
        </label>
      </div>

      {error ? <p className="mt-2 rounded-lg bg-[#F8E0DC] px-2.5 py-1.5 text-[11.5px] text-[#A13C2C]">{error}</p> : null}

      <Button
        onClick={submit}
        disabled={busy}
        className="mt-3 w-full rounded-full bg-brand-green text-white hover:bg-brand-green/90"
      >
        {busy ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : <Banknote className="mr-1.5 h-4 w-4" />}
        Complete replenishment
      </Button>
    </div>
  );
}