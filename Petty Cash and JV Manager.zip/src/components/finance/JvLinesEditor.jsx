import { Plus, Trash2 } from 'lucide-react';
import { CASH_ACCOUNT, EXPENSE_CATEGORIES, peso } from '@/lib/constants';
import { jvTotals } from '@/lib/rules';
import { cn } from '@/lib/utils';

const ACCOUNTS = [
  ...EXPENSE_CATEGORIES.map((category) => ({ code: category.code, name: category.account })),
  { code: CASH_ACCOUNT.code, name: CASH_ACCOUNT.name }
];

const inputClass =
  'w-full rounded-lg border border-brand-line bg-white px-2 py-1.5 text-[12px] outline-none transition focus:border-brand-yellow focus:ring-2 focus:ring-brand-yellow/30 disabled:bg-brand-paper';

export default function JvLinesEditor({ lines = [], onChange, disabled = false, requestTotal }) {
  const totals = jvTotals(lines);
  const matchesTotal = Number(totals.debit.toFixed(2)) === Number((requestTotal || 0).toFixed(2));

  const patch = (index, value) => {
    onChange(lines.map((line, i) => (i === index ? { ...line, ...value } : line)));
  };

  const setAccount = (index, code) => {
    const account = ACCOUNTS.find((item) => item.code === code);
    patch(index, { account_code: account.code, account_name: account.name });
  };

  return (
    <div className="space-y-2.5">
      <div className="hidden gap-2 px-1 text-[9.5px] font-semibold uppercase tracking-[0.12em] text-brand-muted md:grid md:grid-cols-[110px_1fr_1.2fr_110px_110px_30px]">
        <span>Account</span>
        <span>Account title</span>
        <span>Particulars</span>
        <span className="text-right">Debit</span>
        <span className="text-right">Credit</span>
        <span />
      </div>

      {lines.map((line, index) => (
        <div
          key={index}
          className="grid gap-1.5 rounded-xl border border-brand-line/70 bg-white p-2 md:grid-cols-[110px_1fr_1.2fr_110px_110px_30px] md:items-center md:border-0 md:bg-transparent md:p-0"
        >
          <select
            value={line.account_code}
            disabled={disabled}
            onChange={(e) => setAccount(index, e.target.value)}
            className={inputClass}
            aria-label={`Line ${index + 1} account`}
          >
            {ACCOUNTS.map((account) => (
              <option key={account.code} value={account.code}>
                {account.code}
              </option>
            ))}
          </select>
          <input
            value={line.account_name || ''}
            disabled={disabled}
            onChange={(e) => patch(index, { account_name: e.target.value })}
            className={inputClass}
            aria-label={`Line ${index + 1} account title`}
          />
          <input
            value={line.particulars || ''}
            disabled={disabled}
            onChange={(e) => patch(index, { particulars: e.target.value })}
            className={inputClass}
            aria-label={`Line ${index + 1} particulars`}
          />
          <input
            type="number"
            step="0.01"
            min="0"
            value={line.debit || ''}
            disabled={disabled}
            placeholder="0.00"
            onChange={(e) => patch(index, { debit: e.target.value, credit: '' })}
            className={cn(inputClass, 'num text-right')}
            aria-label={`Line ${index + 1} debit`}
          />
          <input
            type="number"
            step="0.01"
            min="0"
            value={line.credit || ''}
            disabled={disabled}
            placeholder="0.00"
            onChange={(e) => patch(index, { credit: e.target.value, debit: '' })}
            className={cn(inputClass, 'num text-right')}
            aria-label={`Line ${index + 1} credit`}
          />
          <button
            type="button"
            onClick={() => onChange(lines.filter((_, i) => i !== index))}
            disabled={disabled}
            aria-label={`Remove line ${index + 1}`}
            className="justify-self-end rounded-lg p-1 text-brand-muted hover:bg-[#F8E0DC] hover:text-[#A13C2C] md:justify-self-center"
          >
            <Trash2 className="h-3.5 w-3.5" />
          </button>
        </div>
      ))}

      <div className="flex flex-wrap items-center justify-between gap-2 border-t border-brand-line/70 pt-2.5">
        <button
          type="button"
          disabled={disabled}
          onClick={() =>
            onChange([
              ...lines,
              { account_code: EXPENSE_CATEGORIES[0].code, account_name: EXPENSE_CATEGORIES[0].account, particulars: '', debit: '', credit: '' }
            ])
          }
          className="inline-flex items-center gap-1.5 rounded-full border border-brand-line bg-white px-3 py-1.5 text-[11.5px] font-medium hover:border-brand-yellow disabled:opacity-50"
        >
          <Plus className="h-3.5 w-3.5" /> Add line
        </button>
        <div className="flex flex-wrap items-center gap-3 text-[11.5px]">
          <span className="text-brand-muted">Debits <span className="num font-semibold text-brand-ink">{peso(totals.debit)}</span></span>
          <span className="text-brand-muted">Credits <span className="num font-semibold text-brand-ink">{peso(totals.credit)}</span></span>
          <span
            className={cn(
              'rounded-full px-2 py-0.5 text-[10.5px] font-semibold',
              totals.balanced && matchesTotal
                ? 'bg-brand-greenSoft text-brand-green'
                : 'bg-[#F8E0DC] text-[#A13C2C]'
            )}
          >
            {totals.balanced && matchesTotal ? 'Balanced' : `Out by ${peso(Math.abs(totals.difference))}`}
          </span>
        </div>
      </div>
    </div>
  );
}