import { STATUS_META, STATUS_TONE } from '@/lib/constants';
import { cn } from '@/lib/utils';

export default function StatusPill({ status, size = 'md', className }) {
  const tone = STATUS_TONE[status] || STATUS_TONE.Draft;
  const label = STATUS_META[status]?.label || status || 'Draft';

  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 rounded-full font-medium ring-1 ring-inset whitespace-nowrap',
        size === 'sm' ? 'px-2 py-0.5 text-[10.5px]' : 'px-2.5 py-1 text-[11.5px]',
        tone,
        className
      )}
    >
      <span className="h-1.5 w-1.5 rounded-full bg-current opacity-70" />
      {label}
    </span>
  );
}