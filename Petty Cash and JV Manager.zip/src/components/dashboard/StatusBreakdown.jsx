import StatusPill from '@/components/StatusPill';
import { compactPeso, peso } from '@/lib/constants';

export default function StatusBreakdown({ rows = [] }) {
  const max = Math.max(1, ...rows.map((row) => row.amount));
  const total = rows.reduce((sum, row) => sum + row.amount, 0);

  return (
    <div className="space-y-3.5">
      {rows.length === 0 ? (
        <p className="text-sm text-muted-foreground">No requests in this view yet.</p>
      ) : null}
      {rows.map((row) => (
        <div key={row.status}>
          <div className="flex items-center justify-between gap-2">
            <StatusPill status={row.status} size="sm" />
            <span className="num text-[12px] font-medium text-muted-foreground">
              {peso(row.amount)}
            </span>
          </div>
          <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-brand-line/50">
            <div
              className="h-full rounded-full bg-gradient-to-r from-brand-yellow to-brand-green transition-all duration-500"
              style={{ width: `${Math.max(4, (row.amount / max) * 100)}%` }}
            />
          </div>
        </div>
      ))}
      {rows.length ? (
        <div className="flex items-center justify-between border-t border-brand-line/70 pt-3 text-[12px]">
          <span className="text-muted-foreground">Total value in view</span>
          <span className="num font-semibold">{compactPeso(total)}</span>
        </div>
      ) : null}
    </div>
  );
}