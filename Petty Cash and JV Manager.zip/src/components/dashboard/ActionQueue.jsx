import { Link } from 'react-router-dom';
import { ArrowUpRight, CheckCircle2 } from 'lucide-react';
import StatusPill from '@/components/StatusPill';
import { peso } from '@/lib/constants';

export default function ActionQueue({ items = [], emptyLabel }) {
  if (!items.length) {
    return (
      <div className="flex flex-col items-center gap-2 rounded-xl border border-dashed border-brand-line bg-brand-paper/40 px-4 py-8 text-center">
        <CheckCircle2 className="h-6 w-6 text-brand-green" strokeWidth={1.8} />
        <p className="text-sm font-medium">{emptyLabel}</p>
        <p className="text-xs text-muted-foreground">Nothing is waiting on you right now.</p>
      </div>
    );
  }

  return (
    <ul className="divide-y divide-brand-line/70">
      {items.map((item) => (
        <li key={`${item.id}-${item.meta}`}>
          <Link
            to={item.to}
            className="group flex items-center gap-3 px-1 py-3 transition-colors hover:bg-brand-greenSoft/30 sm:px-2"
          >
            <span className="min-w-0 flex-1">
              <span className="flex flex-wrap items-center gap-2">
                <span className="num font-heading text-[13px] font-semibold">{item.request_no}</span>
                <StatusPill status={item.status} size="sm" />
                {item.age >= 3 ? (
                  <span className="rounded-full bg-[#F8E0DC] px-2 py-0.5 text-[10px] font-medium text-[#A13C2C]">
                    {item.age}d waiting
                  </span>
                ) : null}
              </span>
              <span className="mt-1 block truncate text-[12.5px] text-muted-foreground">
                {item.branch_name} · {item.requester_name}
              </span>
              <span className="mt-0.5 block text-[11.5px] font-medium text-brand-green">
                {item.meta}
              </span>
            </span>
            <span className="num shrink-0 text-right text-[13px] font-semibold">
              {peso(item.amount)}
            </span>
            <ArrowUpRight className="h-4 w-4 shrink-0 text-brand-muted transition-transform group-hover:-translate-y-0.5 group-hover:text-brand-ink" />
          </Link>
        </li>
      ))}
    </ul>
  );
}