import { cn } from '@/lib/utils';
import { compactPeso, peso } from '@/lib/constants';

export default function FundUsage({ rows = [], limit = 20000, title = 'Petty cash fund' }) {
  return (
    <div className="space-y-3">
      {rows.map((row) => {
        const used = Math.min(row.outstanding, limit);
        const pct = Math.min(100, (used / limit) * 100);
        const tone = pct > 85 ? 'bg-[#C4703F]' : pct > 55 ? 'bg-brand-yellow' : 'bg-brand-green';
        return (
          <div key={row.code || row.name}>
            <div className="flex items-baseline justify-between gap-2">
              <p className="truncate text-[12.5px] font-medium">
                {row.name}
                <span className="ml-1.5 text-[10.5px] uppercase tracking-[0.1em] text-brand-muted">
                  {row.code}
                </span>
              </p>
              <p className="num shrink-0 text-[11.5px] text-muted-foreground">
                {compactPeso(used)} / {compactPeso(limit)}
              </p>
            </div>
            <div className="mt-1.5 h-2 overflow-hidden rounded-full bg-brand-line/50">
              <div
                className={cn('h-full rounded-full transition-all duration-500', tone)}
                style={{ width: `${Math.max(3, pct)}%` }}
              />
            </div>
            <p className="mt-1 text-[10.5px] text-brand-muted">
              {peso(Math.max(0, limit - row.outstanding))} available for replenishment
            </p>
          </div>
        );
      })}
      {rows.length === 0 ? (
        <p className="text-sm text-muted-foreground">No active branch fund in this view.</p>
      ) : null}
    </div>
  );
}