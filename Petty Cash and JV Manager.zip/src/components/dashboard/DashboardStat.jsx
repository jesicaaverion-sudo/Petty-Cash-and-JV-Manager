import { cn } from '@/lib/utils';

const TONES = {
  yellow: 'bg-brand-yellow text-brand-ink',
  amber: 'bg-[#FBEDC4] text-[#8A6608]',
  green: 'bg-brand-greenSoft text-brand-green',
  clay: 'bg-[#F7E4D8] text-brand-clay',
  ink: 'bg-brand-ink text-brand-yellow'
};

export default function DashboardStat({ label, value, sub, tone = 'yellow', icon: Icon, onClick }) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={!onClick}
      className={cn(
        'group relative overflow-hidden rounded-2xl border border-brand-line/80 bg-card p-4 text-left shadow-soft transition-all duration-300',
        onClick && 'hover:-translate-y-0.5 hover:border-brand-yellow/60 hover:shadow-lift'
      )}
    >
      <div className="flex items-start justify-between gap-2">
        <p className="text-[10.5px] font-semibold uppercase tracking-[0.14em] text-brand-muted">
          {label}
        </p>
        {Icon ? (
          <span className={cn('grid h-7 w-7 shrink-0 place-items-center rounded-full', TONES[tone])}>
            <Icon className="h-3.5 w-3.5" strokeWidth={2.2} />
          </span>
        ) : null}
      </div>
      <p className="num mt-2.5 font-heading text-[22px] font-semibold leading-tight md:text-[26px]">
        {value}
      </p>
      <p className="mt-1 text-[11.5px] leading-snug text-muted-foreground">{sub}</p>
    </button>
  );
}