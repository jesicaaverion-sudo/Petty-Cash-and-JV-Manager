import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis
} from 'recharts';
import { compactPeso, peso } from '@/lib/constants';

function ChartTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-xl border border-brand-line bg-white px-3 py-2 shadow-lift">
      <p className="text-[11px] font-semibold uppercase tracking-[0.12em] text-brand-muted">{label}</p>
      {payload.map((entry) => (
        <p key={entry.dataKey} className="num mt-1 text-[12px]">
          <span
            className="mr-1.5 inline-block h-2 w-2 rounded-full"
            style={{ backgroundColor: entry.color }}
          />
          {entry.dataKey === 'submitted' ? 'Submitted' : 'Deposited'}: {peso(entry.value)}
        </p>
      ))}
    </div>
  );
}

export default function AmountTrend({ data = [] }) {
  return (
    <div className="h-[220px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
          <defs>
            <linearGradient id="submittedFill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#F4C430" stopOpacity={0.55} />
              <stop offset="100%" stopColor="#F4C430" stopOpacity={0.02} />
            </linearGradient>
            <linearGradient id="depositedFill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#2E6B4F" stopOpacity={0.4} />
              <stop offset="100%" stopColor="#2E6B4F" stopOpacity={0.02} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 6" stroke="#E7E2D3" vertical={false} />
          <XAxis
            dataKey="label"
            tickLine={false}
            axisLine={false}
            tick={{ fontSize: 11, fill: '#77736A' }}
          />
          <YAxis
            tickLine={false}
            axisLine={false}
            tick={{ fontSize: 10, fill: '#9A968C' }}
            tickFormatter={(value) => compactPeso(value)}
            width={54}
          />
          <Tooltip content={<ChartTooltip />} cursor={{ stroke: '#E7E2D3' }} />
          <Area
            type="monotone"
            dataKey="submitted"
            stroke="#D9A81B"
            strokeWidth={2}
            fill="url(#submittedFill)"
          />
          <Area
            type="monotone"
            dataKey="deposited"
            stroke="#2E6B4F"
            strokeWidth={2}
            fill="url(#depositedFill)"
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}