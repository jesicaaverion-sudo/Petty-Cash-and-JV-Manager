import { Link, NavLink, Outlet, useLocation } from 'react-router-dom';
import {
  Building2,
  FileText,
  LayoutDashboard,
  Plus,
  ReceiptText,
  Settings2
} from 'lucide-react';
import RoleSwitcher from '@/components/RoleSwitcher';
import { useRole } from '@/lib/RoleContext';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import { cn } from '@/lib/utils';

const NAV = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard, roles: ['staff', 'manager', 'finance'], end: true },
  { to: '/requests', label: 'Requests', icon: FileText, roles: ['staff', 'manager', 'finance'] },
  { to: '/requests/new', label: 'New request', icon: Plus, roles: ['staff'] },
  { to: '/finance', label: 'Journal vouchers', icon: ReceiptText, roles: ['finance'] },
  { to: '/settings', label: 'Settings', icon: Settings2, roles: ['staff', 'manager', 'finance'] }
];

function ScopePicker() {
  const { role, branchId, setBranchId, clusterId, setClusterId, branches, clusters } = useRole();

  if (role === 'finance') {
    return (
      <div className="flex items-center gap-2 rounded-full border border-brand-line/80 bg-white/70 px-3 py-1.5 text-[12px] text-brand-inkSoft">
        <Building2 className="h-3.5 w-3.5" />
        All branches
      </div>
    );
  }

  if (role === 'manager') {
    return (
      <Select value={clusterId} onValueChange={setClusterId}>
        <SelectTrigger className="h-9 w-[210px] rounded-full border-brand-line/80 bg-white/70 text-[12.5px]">
          <SelectValue placeholder="Select cluster" />
        </SelectTrigger>
        <SelectContent>
          {clusters.map((cluster) => (
            <SelectItem key={cluster.id} value={cluster.id}>
              {cluster.name}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    );
  }

  return (
    <Select value={branchId} onValueChange={setBranchId}>
      <SelectTrigger className="h-9 w-[210px] rounded-full border-brand-line/80 bg-white/70 text-[12.5px]">
        <SelectValue placeholder="Select branch" />
      </SelectTrigger>
      <SelectContent>
        {branches.map((branch) => (
          <SelectItem key={branch.id} value={branch.id}>
            {branch.name}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}

function ActorBadge() {
  const { identity } = useRole();
  const initials = identity.actorName
    .split(' ')
    .map((part) => part[0])
    .slice(0, 2)
    .join('');

  return (
    <div className="flex items-center gap-2.5 rounded-full border border-brand-line/80 bg-white/70 py-1 pl-1 pr-3">
      <span className="grid h-7 w-7 place-items-center rounded-full bg-brand-green text-[11px] font-semibold text-white">
        {initials}
      </span>
      <span className="leading-tight">
        <span className="block text-[12px] font-medium">{identity.actorName}</span>
        <span className="block text-[10px] uppercase tracking-[0.1em] text-brand-muted">
          {identity.roleLabel}
        </span>
      </span>
    </div>
  );
}

export default function AppShell() {
  const { role, identity } = useRole();
  const location = useLocation();
  const navItems = NAV.filter((item) => item.roles.includes(role));
  const bottomItems = navItems.slice(0, 5);

  return (
    <div className="min-h-screen bg-brand-paper text-brand-ink">
      <header className="no-print sticky top-0 z-40 border-b border-brand-line/80 bg-brand-paper/90 backdrop-blur-xl">
        <div className="mx-auto flex h-16 max-w-[1440px] items-center gap-3 px-3 sm:px-5">
          <Link to="/" className="flex shrink-0 items-center gap-2.5 md:w-[196px]">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-brand-ink font-heading text-[15px] font-semibold text-brand-yellow">
              ₱
            </span>
            <span className="leading-tight">
              <span className="block font-heading text-[14.5px] font-semibold tracking-tight">
                PettyCash
              </span>
              <span className="block text-[9.5px] uppercase tracking-[0.16em] text-brand-muted">
                Replenishment & JV
              </span>
            </span>
          </Link>

          <div className="hidden flex-1 justify-center sm:flex">
            <RoleSwitcher />
          </div>

          <div className="ml-auto hidden items-center gap-2.5 lg:flex">
            <ScopePicker />
            <ActorBadge />
          </div>

          <div className="ml-auto lg:hidden">
            <ScopePicker />
          </div>
        </div>

        <div className="border-t border-brand-line/60 px-3 py-2 sm:hidden">
          <RoleSwitcher compact />
        </div>
      </header>

      <div className="mx-auto flex max-w-[1440px] gap-8 px-0 sm:px-5">
        <aside className="no-print sticky top-16 hidden h-[calc(100vh-4rem)] w-[196px] shrink-0 flex-col py-7 md:flex">
          <nav className="space-y-1">
            {navItems.map((item) => {
              const active = item.end
                ? location.pathname === item.to
                : location.pathname.startsWith(item.to);
              return (
                <NavLink
                  key={item.to}
                  to={item.to}
                  className={cn(
                    'flex items-center gap-2.5 rounded-xl px-3 py-2.5 text-[13px] font-medium transition-all duration-200',
                    active
                      ? 'bg-brand-ink text-brand-paper shadow-soft'
                      : 'text-brand-inkSoft/80 hover:bg-brand-greenSoft/60 hover:text-brand-ink'
                  )}
                >
                  <item.icon className="h-4 w-4" strokeWidth={2} />
                  {item.label}
                </NavLink>
              );
            })}
          </nav>

          <div className="mt-auto rounded-2xl border border-brand-line/80 bg-white/70 p-3.5">
            <p className="text-[10px] font-semibold uppercase tracking-[0.14em] text-brand-muted">
              Working as
            </p>
            <p className="mt-1 font-heading text-[13px] font-semibold">{identity.roleLabel}</p>
            <p className="mt-0.5 text-[11.5px] leading-snug text-muted-foreground">
              {identity.scopeLabel}
            </p>
            <p className="mt-2.5 border-t border-brand-line/70 pt-2 text-[10.5px] text-brand-muted">
              BotiCARD Inc. · San Pablo City
            </p>
          </div>
        </aside>

        <main className="min-w-0 flex-1 px-3 pb-28 pt-5 sm:px-0 sm:pt-7 md:pb-14">
          <Outlet />
        </main>
      </div>

      <nav className="no-print safe-bottom fixed inset-x-0 bottom-0 z-40 border-t border-brand-line/80 bg-brand-paper/95 backdrop-blur-xl md:hidden">
        <div className="mx-auto flex max-w-md items-stretch justify-between px-2">
          {bottomItems.map((item) => {
            const active = item.end
              ? location.pathname === item.to
              : location.pathname.startsWith(item.to);
            return (
              <NavLink
                key={item.to}
                to={item.to}
                className={cn(
                  'flex flex-1 flex-col items-center gap-1 py-2.5 text-[10px] font-medium transition-colors',
                  active ? 'text-brand-ink' : 'text-brand-muted'
                )}
              >
                <span
                  className={cn(
                    'grid h-8 w-8 place-items-center rounded-full transition-all',
                    active ? 'bg-brand-yellow text-brand-ink' : 'bg-transparent'
                  )}
                >
                  <item.icon className="h-[18px] w-[18px]" strokeWidth={2} />
                </span>
                <span className="truncate">{item.label}</span>
              </NavLink>
            );
          })}
        </div>
      </nav>
    </div>
  );
}