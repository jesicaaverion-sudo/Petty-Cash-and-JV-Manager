import { useRole } from '@/lib/RoleContext';
import { ROLES } from '@/lib/constants';
import { cn } from '@/lib/utils';

export default function RoleSwitcher({ compact = false }) {
  const { role, setRole } = useRole();

  return (
    <div
      className={cn(
        'inline-flex items-center gap-1 rounded-full border border-brand-line/80 bg-white/70 p-1 shadow-soft',
        compact && 'w-full justify-between'
      )}
      role="tablist"
      aria-label="Switch role"
    >
      {ROLES.map((option) => {
        const active = option.id === role;
        return (
          <button
            key={option.id}
            type="button"
            role="tab"
            aria-selected={active}
            onClick={() => setRole(option.id)}
            className={cn(
              'flex flex-1 items-center justify-center gap-1.5 rounded-full px-3 py-1.5 text-[12.5px] font-medium transition-all duration-200 sm:flex-none',
              active
                ? 'bg-brand-yellow text-brand-ink shadow-[0_2px_8px_-2px_rgba(244,196,48,0.7)]'
                : 'text-brand-inkSoft/70 hover:bg-brand-greenSoft/60 hover:text-brand-ink'
            )}
          >
            <span
              className={cn(
                'hidden h-1.5 w-1.5 rounded-full sm:block',
                active ? 'bg-brand-ink/60' : 'bg-brand-line'
              )}
            />
            <span className="hidden sm:inline">{option.label}</span>
            <span className="sm:hidden">{option.short}</span>
          </button>
        );
      })}
    </div>
  );
}