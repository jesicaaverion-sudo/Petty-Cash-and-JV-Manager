import { Inbox } from 'lucide-react';

export default function EmptyState({ title, description, action, icon: Icon = Inbox }) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 rounded-2xl border border-dashed border-brand-line bg-white/50 px-6 py-12 text-center">
      <span className="grid h-11 w-11 place-items-center rounded-full bg-brand-greenSoft text-brand-green">
        <Icon className="h-5 w-5" strokeWidth={1.9} />
      </span>
      <p className="font-heading text-[14px] font-semibold">{title}</p>
      {description ? (
        <p className="max-w-sm text-[12.5px] leading-relaxed text-muted-foreground">{description}</p>
      ) : null}
      {action ? <div className="mt-2">{action}</div> : null}
    </div>
  );
}