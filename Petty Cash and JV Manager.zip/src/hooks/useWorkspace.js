import { useCallback, useEffect, useState } from 'react';
import { fetchWorkspace } from '@/lib/data';

export default function useWorkspace() {
  const [state, setState] = useState({
    loading: true,
    error: null,
    requests: [],
    jvs: [],
    deposits: []
  });

  const load = useCallback(async ({ quiet = false } = {}) => {
    if (!quiet) setState((prev) => ({ ...prev, loading: true }));
    try {
      const data = await fetchWorkspace();
      setState({ loading: false, error: null, ...data });
    } catch (error) {
      setState((prev) => ({ ...prev, loading: false, error: error.message || 'Unable to load records.' }));
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  return { ...state, reload: load };
}